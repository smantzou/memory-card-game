public class Game_Handler {
    private int count0=0,count1=0,count2=0,count3=0,vcount0=0,vcount1=0,vcount2=0,vcount3=0,max,x,r;
    private String WinnerName;
    private boolean multiduel,flag;
    private String table;
    private Resource_Manager objrm= new Resource_Manager();
    public Game_Handler(){

    }

    /**
     * Μέθοδος που ελέγχει αν ένα όνομα στον πίνακα ονομάτων αντιστοιχεί σε Υπολογιστή και επιστρέφει
     * @return flag
     * ανάλογη με το αν είναι η όχι
     */
    public boolean CheckCPUPlayerForLeader(){
        flag = false;

        if(Player_Names.Pnames[x]==null){
            return flag;
        }
        if  (  (Player_Names.Pnames[x].equals("CPUGOLDFISH1")|| Player_Names.Pnames[x].equals("CPUGOLDFISH2") || Player_Names.Pnames[x].equals("CPUGOLDFISH3") ||
                Player_Names.Pnames[x].equals("CPUKANGAROO1") || Player_Names.Pnames[x].equals("CPUKANGAROO2") || Player_Names.Pnames[x].equals("CPUKANGAROO3") ||
                Player_Names.Pnames[x].equals("CPUELEPHANT1") || Player_Names.Pnames[x].equals("CPUELEPHANT2") || Player_Names.Pnames[x].equals("CPUELEPHANT3"))) {
            flag = true;
        }



        return flag;
    }

    /**
     * Μέθοδος που καλείται για την αποθήκευση νέων παικτών και ενημέρωση των στοιχείων High Score των παικτών
     * χρησιμοποιώντας αντικείμενα τύπου Save_Data και των συναρτήσεων της κλάσης Resource_Manager.
     */
    public void ManageLeaderBoard(){
        x=0;
        while(x<Player_Names.Pnames.length){

            if(!CheckCPUPlayerForLeader()){

                if(!objrm.CheckExistance(Player_Names.Pnames[x])){
                    if(Player_Names.Pnames[x]!=null) {
                        Save_Data data = new Save_Data();
                        data.NewPlayer(Player_Names.Pnames[x]);
                        objrm.AddObject(data);
                        if(WinnerName.equals(Player_Names.Pnames[x])) {
                            objrm.ChangeStats(Player_Names.Pnames[x], GetMoves(x), true,multiduel,table);
                        }
                        else{
                            objrm.ChangeStats(Player_Names.Pnames[x],GetMoves(x),false,multiduel,table);
                        }

                    }
                }
                else{
                    if(WinnerName.equals(Player_Names.Pnames[x])) {
                        objrm.ChangeStats(Player_Names.Pnames[x], GetMoves(x), true,multiduel,table);
                    }
                    else{
                        objrm.ChangeStats(Player_Names.Pnames[x],GetMoves(x),false,multiduel,table);
                    }
                }
            }
            x++;
        }
        objrm.save();
        objrm.Write();


    }

    /**
     * Μέθοδος που δέχεται μια
     * @param r η οποία αντιστοιχεί στην θέση ενός παίκτη στον πίνακα ονομάτων
     *  και αυξάνει τον αριθμό κινήσεων του και έπειτα επιστρέφει
     * @return true/false
     * ανάλογα με το αν πέτυχει τον στόχο της.
     */
    public boolean CountMoves(int r){
        if (r==0){
            count0++;
        }
        else if(r==1){
            count1++;
        }
        else if(r==2){
            count2++;

        }
        else {
            count3++;
        }
        if(count0!=0){
            return true;
        }
        if(count1!=0){
            return true;
        }
        if(count2!=0){
            return true;
        }
        if(count3!=0){
            return true;
        }
        return false;
    }

    /**
     *  Μέθοδος που δέχεται μια
     * @param r η οποία αντιστοιχεί στην θέση ενός παίκτη στον πίνακα ονομάτων
     *  και αυξάνει τον αριθμό σωστλων κινήσεων του και έπειτα επιστρέφει
     * @return true/false
     * ανάλογα με το αν πέτυχει τον στόχο της.
     *
     */
    public boolean CountVictories(int r){
        if (r==0){
            vcount0++;
        }
        else if(r==1){
            vcount1++;
        }
        else if(r==2){
            vcount2++;

        }
        else {
            vcount3++;
        }
        if(vcount0!=0){
            return true;
        }
        if(vcount1!=0){
            return true;
        }
        if(vcount2!=0){
            return true;
        }
        if(vcount3!=0){
            return true;
        }
        return false;
    }

    /**
     * Μέθοδος που αθροίζει τα counter σωστών κινήσεων και έπειτα επιστρέφει
     * @return c το άθροισμα
     */
    public int VicSum(){
        int c = vcount0+vcount2+vcount1+vcount3;
        return c;
    }

    /**
     * Μέθοδος που επιστρέφει
     * @return max το μέγιστο vcount (δηλαδή το αριθμό ζευγαριών του νικητή)
     */
    public int WhoWon(){
        int max = vcount0;
        r=0;
        if (vcount1 > max) {
            max=vcount1;
            r=1;
        }
        if(vcount2>max){
            max=vcount2;
            r=2;
        }
        if(vcount3>max){
            max =vcount3;
            r=3;
        }
        return max;



    }

    /**
     * Μέθοδος που επιστρέφει
     * @return r (δηλαδή την θέση του νικητή στον πίνακα ονομάτων)
     */
    public int WhoR(){
        max = vcount0;
        r=0;
        if (vcount1 > max) {
            max=vcount1;
            r=1;
        }
        if(vcount2>max){
            max=vcount2;
            r=2;
        }
        if(vcount3>max){
            max =vcount3;
            r=3;
        }

        return r;

    }

    /**
     * Μέθοδος που ελέγχει την περίπτωηση ισοπαλίας  και επιστρέψει
     * @return true/false ανάλογο με την κατάσταση ισοπαλίας
     */
    public boolean isDraw(){
        int sum =0;
        if (max==vcount0){
            sum++;
        }
        else if(max==vcount1){
            sum++;
        }
        else if(max==vcount2){
            sum++;
        }
        else if(max==vcount3){
            sum++;
        }
        if(sum>1){
            return true;
        }
        else{
            return false;
        }
    }

    /**
     * Μέθοδος που δέχεται
     * @param r η οποία είναι η θέση ενός παίκτη στον πίνακα ονομάτων
     * @return και επιστρέφει τις κινήσεις του
     */
    public int GetMoves(int r) {
        if (r == 0) {
            return count0;
        } else if (r == 1) {
            return count1;
        } else if (r == 2) {
            return count2;
        } else {
            return count3;
        }

    }

    /**
     * Μέθοδος που δέχεται
     * @param wname το όνομα του νικητή του γύρου και
     * το αποθηκεύει στην μεταβλητή Winnername
     */
    public void setWinnerName(String wname){
        WinnerName=wname;
    }

    /**
     * Μέθοδος που
     * @param t δέχεται τον τύπο παιχνιδιού του γύρου
     * και τον αποθηκεύει στην μεταβλητή table
     */
    public void setTable(String t){
        table=t;

    }

    /**
     * Μέθοδος που δέχεται μια boolean μεταβλητή
     * @param md η οποία δείχνει αν το παιχνίδι είναι μονό η όχι
     * και το αποθηκεύει σε μία μεταβλητή boolean multiduel
     */
    public void setMultiduel(boolean md){
        multiduel=md;
    }
}
