public class Player_Names {
    static String[] Pnames;

    /**
     * Αρχικοποίηση πίνακα ονομάτων.
     */
    public Player_Names(){
        Pnames = new String[4];
    }
}
