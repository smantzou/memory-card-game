import java.io.Serializable;

public class Save_Data implements Serializable{

    private static final long serialVersionUID=1L;

    private String name;

    private int bsteps;
    private int dsteps;
    private int tsteps;
    private int bwins;
    private int dwins;
    private int twins;
    private int duelwins;
    public Save_Data(){

    }

    /**
     * Μέθοδος που δέχεται το
     * @param name (όνομα ενός παίκτη)
     * και έπειτα αρχικοποιεί τις παραμέτρους του
     */
    public boolean NewPlayer(String name){
        this.name=name;
        bwins=0;
        dwins=0;
        twins=0;
        duelwins=0;
        bsteps=0;
        dsteps=0;
        tsteps=0;
        return true;
    }

    /**
     * Μέθοδοι αύξησεις των νικών ενός παίκτη στα αντίστοιχα παιχνίδια
     */
    public void Basic_Win(){
        bwins++;
    }
    public void Double_Win(){
        dwins++;
    }
    public void Triple_Win(){
        twins++;
    }
    public void Duel_Win(){
        duelwins++;
    }

    /**
     * Μέθοδοι που δέχονται τις
     * @param moves κινήσεις ενός παίκτη
     * και έπειτα ενημερώνουν τις υπάρχουσες αν οι δεχόμενες είναι λιγότερες
     */
    public void Update_BSteps(int moves){
        if(bsteps==0){
            bsteps=moves;
        }
        if(bsteps>moves){
            bsteps=moves;
        }
    }
    public void Update_DSteps(int moves){
        if(dsteps==0){
            dsteps=moves;
        }
        if(dsteps>moves){
            dsteps=moves;
        }
    }
    public void Update_TSteps(int moves){
        if(tsteps==0){
            tsteps=moves;
        }
        if(tsteps>moves){
            tsteps=moves;
        }
    }

    /**
     * Μέθοδοι που επιστρέφουν
     * @return το κάθε ένα από τα στοιχεία νικών η βημάτων και ονόματος των παικτών
     */
    public int GetBasicWins(){
        return bwins;
    }
    public int GetDoubleWins(){
        return dwins;
    }
    public int GetTripleWins(){
        return twins;
    }
    public int GetDuelWins(){return duelwins;}
    public int GetBasicSteps(){
        return bsteps;
    }
    public int GetDoubleSteps(){return dsteps; }
    public int GetTripleSteps(){
        return tsteps;
    }
    public  String getName(){return name;}

}

