import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Multi_Modals {
    private JDialog MMDialog,CPUDialog;
    private JPanel MMPanel,CPUPanel;
    private JLabel MMLabel1;
    private JLabel MMLabel2;
    private JLabel MMLabel3;
    private JLabel MMLabel4;
    private JLabel CPULabel;
    private JTextField MMText1;
    private JTextField MMText2;
    private JTextField MMText3;
    private JTextField MMText4;
    private JButton OK,cpu1,cpu2,cpu3,dif1,dif2,dif3;
    private String player1;
    private String player2;
    private String player3;
    private Select_Mode objsm;
    private int x;

    /**
     * Αρχικοποίηση των απαραίτητων στοιχείων για την δημιουργία του παραθύρου για την επιλογή του αριθμού των παικτών στο πολλαπλό παιχνίδι.
     */
    public Multi_Modals(){
         MMDialog = new JDialog();
         CPUDialog = new JDialog();
         MMPanel = new JPanel();
         CPUPanel = new JPanel();
         MMLabel1 = new JLabel();
         MMLabel2 = new JLabel();
         MMLabel3 = new JLabel();
         MMLabel4 = new JLabel();
         CPULabel = new JLabel(Start_Frame.messages.getString("difcpu"));
         MMText1= new JTextField();
         MMText2= new JTextField();
         MMText3= new JTextField();
         MMText4= new JTextField();
         OK = new JButton("OK");
         cpu1 = new JButton(Start_Frame.messages.getString("actcpu1"));
         cpu2 = new JButton(Start_Frame.messages.getString("actcpu2"));
         cpu3 = new JButton(Start_Frame.messages.getString("actcpu3"));
         dif1 = new JButton(Start_Frame.messages.getString("goldfish"));
         dif2 = new JButton(Start_Frame.messages.getString("kangaroo"));
         dif3 = new JButton(Start_Frame.messages.getString("elephant"));
         objsm = new Select_Mode();

    }

    /**
     * Μέθοδος που δημιουργεί το modal παράθυρο για την εισαγώγη των ονομάτων δύο παικτών.
     */
    public void P2Modal(){
        MMDialog.setSize(800,500);
        MMDialog.setLocationRelativeTo(null);
        MMDialog.setModal(true);
        MMDialog.setResizable(false);

        MMPanel.setLayout(null);
        MMDialog.add(MMPanel);


        MMLabel1.setText(Start_Frame.messages.getString("entername1"));
        MMLabel2.setText(Start_Frame.messages.getString("entername2"));
        MMLabel1.setBounds(130, 100, 300, 100);
        MMLabel2.setBounds(130, 200, 300, 100);
        MMPanel.add(MMLabel1);
        MMPanel.add(MMLabel2);

        OK.setBounds(350, 380, 60, 60);
        OK.addActionListener(new entermulti2());
        MMPanel.add(OK);

        cpu1.setBounds(601, 230, 150, 40);
        cpu1.addActionListener(new activatecpu());
        MMPanel.add(cpu1);

        MMText1.setBounds(401, 130, 200, 40);
        MMText2.setBounds(401, 230, 200, 40);
        MMPanel.add(MMText1);
        MMPanel.add(MMText2);

        MMDialog.setVisible(true);
        MMPanel.setVisible(true);
    }

    /**
     *Δημιουργία παραθύρου για την επιλογή δυσκολίας της CPU για το πολλαπλό παιχνίδι.
     */
    public void makeCPUmodal(){
        CPUDialog.setSize(800,500);
        CPUDialog.setLocationRelativeTo(null);
        CPUDialog.setModal(true);
        CPUDialog.setResizable(false);

        CPUPanel.setLayout(null);
        CPUDialog.add(CPUPanel);

        CPULabel.setBounds(300, -20, 300, 100);
        CPUPanel.add(CPULabel);

        dif1.setBounds(320, 80, 150, 80);
        dif1.addActionListener(new cpudifficulty());
        CPUPanel.add(dif1);

        dif2.setBounds(320, 180, 150, 80);
        dif2.addActionListener(new cpudifficulty());
        CPUPanel.add(dif2);

        dif3.setBounds(320, 280, 150, 80);
        dif3.addActionListener(new cpudifficulty());
        CPUPanel.add(dif3);

        CPUPanel.setVisible(true);
        CPUDialog.setVisible(true);


    }

    /**
     * Κλάση Actionlistener για την επιλογή της δυσκολίας CPU στο πολλαπλό παιχνίδι.
     */
    class cpudifficulty implements ActionListener{
        @Override
        public void actionPerformed(ActionEvent event){
            if(event.getSource()==dif1){
                if(x==2){
                    MMText2.setText("CPUGOLDFISH1");
                }
                else if(x==3){
                    MMText3.setText("CPUGOLDFISH2");
                }
                else{
                    MMText4.setText("CPUGOLDFISH3");
                }

            }
            else if(event.getSource()==dif2){
                if(x==2){
                    MMText2.setText("CPUKANGAROO1");
                }
                else if(x==3){
                    MMText3.setText("CPUKANGAROO2");
                }
                else{
                    MMText4.setText("CPUKANGAROO3");
                }
            }
            else{
                if(x==2){
                    MMText2.setText("CPUELEPHANT1");
                }
                else if(x==3){
                    MMText3.setText("CPUELEPHANT2");
                }
                else{
                    MMText4.setText("CPUELEPHANT3");
                }
            }
            CPUDialog.setModal(false);
            CPUDialog.dispose();
        }

    }

    /**
     * Κλάση Actionlistener η οποία αποθηκεύει τα ονόματα των δύο παικτών στο πολλαπλό παιχνίδι.
     */
    class entermulti2 implements ActionListener{
        public void actionPerformed(ActionEvent event){
            if(event.getSource()==OK){

                player1= MMText1.getText();
                player2=MMText2.getText();

                Player_Names.Pnames[0]=player1;
                Player_Names.Pnames[1]=player2;

                MMDialog.setModal(false);
                MMDialog.dispose();
                objsm.SMode();
            }
        }
    }

    /**
     * Κλάση Actionlistener η οποία δημιουργεί το ανάλογο modal παράθυρο αντίστοιχο με τον επιλεγμένο αριθμό παικτών.
     */
    class activatecpu implements ActionListener{
        @Override
        public void actionPerformed(ActionEvent event){
            if(event.getSource()==cpu1){
                x=2;
               makeCPUmodal();
            }
            else if(event.getSource()==cpu2){
                x=3;
                makeCPUmodal();
            }
            else{
                x=4;
                makeCPUmodal();
            }
        }
    }

    /**
     * Μέθοδος που δημιουργεί το modal παράθυρο για την εισαγώγη των ονομάτων τριών παικτών.
     */
    public void P3Modal(){
        MMDialog.setSize(800,500);
        MMDialog.setLocationRelativeTo(null);
        MMDialog.setModal(true);
        MMDialog.setResizable(false);

        MMPanel.setLayout(null);
        MMDialog.add(MMPanel);


        MMLabel1.setText(Start_Frame.messages.getString("entername1"));
        MMLabel2.setText(Start_Frame.messages.getString("entername2"));
        MMLabel3.setText(Start_Frame.messages.getString("entername3"));

        MMLabel1.setBounds(130, 100, 300, 100);
        MMLabel2.setBounds(130, 150, 300, 100);
        MMLabel3.setBounds(130, 200, 300, 100);

        MMPanel.add(MMLabel1);
        MMPanel.add(MMLabel2);
        MMPanel.add(MMLabel3);

        OK.setBounds(350, 380, 60, 60);
        OK.addActionListener(new entermulti3());
        MMPanel.add(OK);

        cpu1.setBounds(601, 180, 150, 40);
        cpu1.addActionListener(new activatecpu());
        MMPanel.add(cpu1);
        cpu2.setBounds(601, 230, 150, 40);
        cpu2.addActionListener(new activatecpu());
        MMPanel.add(cpu2);

        MMText1.setBounds(401, 130, 200, 40);
        MMText2.setBounds(401, 180, 200, 40);
        MMText3.setBounds(401, 230, 200, 40);

        MMPanel.add(MMText1);
        MMPanel.add(MMText2);
        MMPanel.add(MMText3);

        MMDialog.setVisible(true);
        MMPanel.setVisible(true);

    }

    /**
     * Κλάση Actionlistener η οποία αποθηκεύει τα ονόματα τριών παικτών για το πολλαπλό παιχνίδι.
     */
    class entermulti3 implements ActionListener{
        public void actionPerformed(ActionEvent event){
            if(event.getSource()==OK){

                player1= MMText1.getText();
                player2=MMText2.getText();
                player3=MMText3.getText();

                Player_Names.Pnames[0]=player1;
                Player_Names.Pnames[1]=player2;
                Player_Names.Pnames[2]=player3;

                MMDialog.setModal(false);
                MMDialog.dispose();
                objsm.SMode();
            }
        }
    }


    /**
     * Μέθοδος που δημιουργεί το modal παράθυρο για την εισαγώγη των ονομάτων τεσσάρων παικτών.
     */
    public void P4Modal(){
        MMDialog.setSize(800,500);
        MMDialog.setLocationRelativeTo(null);
        MMDialog.setModal(true);
        MMDialog.setResizable(false);

        MMPanel.setLayout(null);
        MMDialog.add(MMPanel);


        MMLabel1.setText(Start_Frame.messages.getString("entername1"));
        MMLabel2.setText(Start_Frame.messages.getString("entername2"));
        MMLabel3.setText(Start_Frame.messages.getString("entername3"));
        MMLabel4.setText(Start_Frame.messages.getString("entername4"));

        MMLabel1.setBounds(130, 100, 300, 100);
        MMLabel2.setBounds(130, 150, 300, 100);
        MMLabel3.setBounds(130, 200, 300, 100);
        MMLabel4.setBounds(130, 250, 300, 100);

        MMPanel.add(MMLabel1);
        MMPanel.add(MMLabel2);
        MMPanel.add(MMLabel3);
        MMPanel.add(MMLabel4);

        OK.setBounds(350, 380, 60, 60);
        OK.addActionListener(new entermulti4());
        MMPanel.add(OK);

        cpu1.setBounds(601, 180, 150, 40);
        cpu1.addActionListener(new activatecpu());
        MMPanel.add(cpu1);
        cpu2.setBounds(601, 230, 150, 40);
        cpu2.addActionListener(new activatecpu());
        MMPanel.add(cpu2);
        cpu3.setBounds(601, 280, 150, 40);
        cpu3.addActionListener(new activatecpu());
        MMPanel.add(cpu3);

        MMText1.setBounds(401, 130, 200, 40);
        MMText2.setBounds(401, 180, 200, 40);
        MMText3.setBounds(401, 230, 200, 40);
        MMText4.setBounds(401, 280, 200, 40);

        MMPanel.add(MMText1);
        MMPanel.add(MMText2);
        MMPanel.add(MMText3);
        MMPanel.add(MMText4);

        MMDialog.setVisible(true);
        MMPanel.setVisible(true);

    }

    /**
     * Κλάση Actionlistener η οποία αποθηκεύει τα ονόματα τεσσάρων παικτών για το πολλαπλό παιχνίδι.
     */
    class entermulti4 implements ActionListener{
        public void actionPerformed(ActionEvent event){
            if(event.getSource()==OK){

                player1= MMText1.getText();
                player2=MMText2.getText();
                player3=MMText3.getText();
                String player4 = MMText4.getText();

                Player_Names.Pnames[0]=player1;
                Player_Names.Pnames[1]=player2;
                Player_Names.Pnames[2]=player3;
                Player_Names.Pnames[3]= player4;

                MMDialog.setModal(false);
                MMDialog.dispose();
                objsm.SMode();
            }
        }
    }


}
