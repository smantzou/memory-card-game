import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;

public class Duel_Graphics extends Duel_Table {
    private final Game_Handler objgh;
    private Resource_Manager objrm = new Resource_Manager();
    private Object GridLayout = new GridLayout(4, 6, 5, 3);
    private HashMap HashButton ;
    private JFrame dgframe;
    private JPanel dgpanel;
    private JPanel dgpanel2;
    private JPanel dgpanel3;
    private JLabel dglabel,dglabel2;
    private JButton dg1;
    private JButton dg2;
    private JButton dg3;
    private JButton dg4;
    private JButton dg5;
    private JButton dg6;
    private JButton dg7;
    private JButton dg8;
    private JButton dg9;
    private JButton dg10;
    private JButton dg11;
    private JButton dg12;
    private JButton dg13;
    private JButton dg14;
    private JButton dg15;
    private JButton dg16;
    private JButton dg17;
    private JButton dg18;
    private JButton dg19;
    private JButton dg20;
    private JButton dg21;
    private JButton dg22;
    private JButton dg23;
    private JButton dg24;
    private JButton dg25;
    private JButton dg26;
    private JButton dg27;
    private JButton dg28;
    private JButton dg29;
    private JButton dg30;
    private JButton dg31;
    private JButton dg32;
    private JButton dg33;
    private JButton dg34;
    private JButton dg35;
    private JButton dg36;
    private JButton dg37;
    private JButton dg38;
    private JButton dg39;
    private JButton dg40;
    private JButton dg41;
    private JButton dg42;
    private JButton dg43;
    private JButton dg44;
    private JButton dg45;
    private JButton dg46;
    private JButton dg47;
    private JButton dg48;
    private JButton Rb2;
    private ImageIcon closeIcon, icon;
    private String imgname, imgname2, imgName;
    private int count = 0;
    private int vcount0=0,vcount1=0,count0=0,count1=0,r=0,max,numplayers=0,bpos;
    private CPU_Player objcp = new CPU_Player(6,8);
    private boolean flag=false;
    private  java.util.Timer pause = new Timer();


    /**
     *  Άρχικοποίηση των στοιχείων για τη δημιουργία του παραθύρου παιχνιδιού στη μονομαχία
     */
    public Duel_Graphics(){
        objgh = new Game_Handler();
        objgh.setMultiduel(true);
        objgh.setTable("Duel");

        dgframe = new JFrame("Memory Card Game!");
        dgpanel = new JPanel();
        dgpanel2 = new JPanel();
        dgpanel3 = new JPanel();
        dglabel = new JLabel();
        dglabel2 = new JLabel();
        dg1 = new JButton();
        dg2 = new JButton();
        dg3 = new JButton();
        dg4 = new JButton();
        dg5 = new JButton();
        dg6 = new JButton();
        dg7 = new JButton();
        dg8 = new JButton();
        dg9 = new JButton();
        dg10 = new JButton();
        dg11 = new JButton();
        dg12 = new JButton();
        dg13 = new JButton();
        dg14 = new JButton();
        dg15 = new JButton();
        dg16 = new JButton();
        dg17 = new JButton();
        dg18 = new JButton();
        dg19 = new JButton();
        dg20 = new JButton();
        dg21 = new JButton();
        dg22 = new JButton();
        dg23 = new JButton();
        dg24 = new JButton();
        dg25 = new JButton();
        dg26 = new JButton();
        dg27 = new JButton();
        dg28 = new JButton();
        dg29 = new JButton();
        dg30 = new JButton();
        dg31 = new JButton();
        dg32 = new JButton();
        dg33 = new JButton();
        dg34 = new JButton();
        dg35 = new JButton();
        dg36 = new JButton();
        dg37 = new JButton();
        dg38 = new JButton();
        dg39 = new JButton();
        dg40 = new JButton();
        dg41 = new JButton();
        dg42 = new JButton();
        dg43 = new JButton();
        dg44 = new JButton();
        dg45 = new JButton();
        dg46 = new JButton();
        dg47 = new JButton();
        dg48 = new JButton();
        HashButton = new HashMap<JButton,Integer>();
        super.CreatePTable();
        super.ShuffleDTrue1();
        super.ShuffleDTrue2();

        SetDefaultIcon();
        try {
            objrm.load("LeaderBoard.txt");
        } catch (IOException e) {
            e.printStackTrace();
        }




    }

    /**
     * Μέθοδος για την εισαγωγή της "κλειστής" εικόνας σε όλα τα κουμπιά/κάρτες στην αρχή του παιχνιδιού
     */
    public void SetDefaultIcon() {

        imgName = "ergasia eikones/cardclose.jpg";
        URL imageURL = getClass().getResource(imgName);

        closeIcon = new ImageIcon(imageURL);
        dg1.setIcon(closeIcon);
        dg2.setIcon(closeIcon);
        dg3.setIcon(closeIcon);
        dg4.setIcon(closeIcon);
        dg5.setIcon(closeIcon);
        dg6.setIcon(closeIcon);
        dg7.setIcon(closeIcon);
        dg8.setIcon(closeIcon);
        dg9.setIcon(closeIcon);
        dg10.setIcon(closeIcon);
        dg11.setIcon(closeIcon);
        dg12.setIcon(closeIcon);
        dg13.setIcon(closeIcon);
        dg14.setIcon(closeIcon);
        dg15.setIcon(closeIcon);
        dg16.setIcon(closeIcon);
        dg17.setIcon(closeIcon);
        dg18.setIcon(closeIcon);
        dg19.setIcon(closeIcon);
        dg20.setIcon(closeIcon);
        dg21.setIcon(closeIcon);
        dg22.setIcon(closeIcon);
        dg23.setIcon(closeIcon);
        dg24.setIcon(closeIcon);
        dg25.setIcon(closeIcon);
        dg26.setIcon(closeIcon);
        dg27.setIcon(closeIcon);
        dg28.setIcon(closeIcon);
        dg29.setIcon(closeIcon);
        dg30.setIcon(closeIcon);
        dg31.setIcon(closeIcon);
        dg32.setIcon(closeIcon);
        dg33.setIcon(closeIcon);
        dg34.setIcon(closeIcon);
        dg35.setIcon(closeIcon);
        dg36.setIcon(closeIcon);
        dg37.setIcon(closeIcon);
        dg38.setIcon(closeIcon);
        dg39.setIcon(closeIcon);
        dg40.setIcon(closeIcon);
        dg41.setIcon(closeIcon);
        dg42.setIcon(closeIcon);
        dg43.setIcon(closeIcon);
        dg44.setIcon(closeIcon);
        dg45.setIcon(closeIcon);
        dg46.setIcon(closeIcon);
        dg47.setIcon(closeIcon);
        dg48.setIcon(closeIcon);
    }

    /**
     * Μέθοδος για τη δημιουργία του πίνακα που αντιστοιχίζει τα κουμπιά με ακέραιους αριθμούς/θέσεις
     *  και επιστρέφει τιμή για το αν πέτυχε το σκοπό της
     * @return true/false
     */
    public boolean HashStart(){
        HashButton.put(dg1,1);
        HashButton.put(dg2,2);
        HashButton.put(dg3,3);
        HashButton.put(dg4,4);
        HashButton.put(dg5,5);
        HashButton.put(dg6,6);
        HashButton.put(dg7,7);
        HashButton.put(dg8,8);
        HashButton.put(dg9,9);
        HashButton.put(dg10,10);
        HashButton.put(dg11,11);
        HashButton.put(dg12,12);
        HashButton.put(dg13,13);
        HashButton.put(dg14,14);
        HashButton.put(dg15,15);
        HashButton.put(dg16,16);
        HashButton.put(dg17,17);
        HashButton.put(dg18,18);
        HashButton.put(dg19,19);
        HashButton.put(dg20,20);
        HashButton.put(dg21,21);
        HashButton.put(dg22,22);
        HashButton.put(dg23,23);
        HashButton.put(dg24,24);
        HashButton.put(dg25,25);
        HashButton.put(dg26,26);
        HashButton.put(dg27,27);
        HashButton.put(dg28,28);
        HashButton.put(dg29,29);
        HashButton.put(dg30,30);
        HashButton.put(dg31,31);
        HashButton.put(dg32,32);
        HashButton.put(dg33,33);
        HashButton.put(dg34,34);
        HashButton.put(dg35,35);
        HashButton.put(dg36,36);
        HashButton.put(dg37,37);
        HashButton.put(dg38,38);
        HashButton.put(dg39,39);
        HashButton.put(dg40,40);
        HashButton.put(dg41,41);
        HashButton.put(dg42,42);
        HashButton.put(dg43,43);
        HashButton.put(dg44,44);
        HashButton.put(dg45,45);
        HashButton.put(dg46,46);
        HashButton.put(dg47,47);
        HashButton.put(dg48,48);
        for(Object x : HashButton.keySet()){
            if(HashButton.get(x)==null){
                return false;
            }
        }
        return true;
    }

    /**
     * Μέθοδος εύρεσης του αριθμού των παικτών
     */
    public void NPmake(){
        for(int i=0;i<2;i++){
            if(Player_Names.Pnames[i]==null){
                break;
            }
            numplayers++;
        }
    }

    /**
     * Μέθοδος για τη δημιουργία του παραθύρου για το βασικό παιχνίδι
     */
    public void MakeDTable() {
        NPmake();
        HashStart();

        dgframe.setSize(1200,800);
        dgframe.setLocationRelativeTo(null);
        dgframe.setResizable(false);

        dglabel2.setText(Player_Names.Pnames[0]);
        dglabel2.setBounds(580, -10, 1000, 100);
        dgpanel2.add(dglabel2);
        dglabel.setText(Start_Frame.messages.getString("nowplaying"));
        dglabel.setBounds(550, -30, 1000, 100);
        dgpanel2.add(dglabel);

        dg1.addActionListener(new opencard());
        dgpanel.add(dg1);
        dg2.addActionListener(new opencard());
        dgpanel.add(dg2);
        dg3.addActionListener(new opencard());
        dgpanel.add(dg3);
        dg4.addActionListener(new opencard());
        dgpanel.add(dg4);
        dg5.addActionListener(new opencard());
        dgpanel.add(dg5);
        dg6.addActionListener(new opencard());
        dgpanel.add(dg6);
        dg7.addActionListener(new opencard());
        dgpanel.add(dg7);
        dg8.addActionListener(new opencard());
        dgpanel.add(dg8);
        dg9.addActionListener(new opencard());
        dgpanel.add(dg9);
        dg10.addActionListener(new opencard());
        dgpanel.add(dg10);
        dg11.addActionListener(new opencard());
        dgpanel.add(dg11);
        dg12.addActionListener(new opencard());
        dgpanel.add(dg12);
        dg13.addActionListener(new opencard());
        dgpanel.add(dg13);
        dg14.addActionListener(new opencard());
        dgpanel.add(dg14);
        dg15.addActionListener(new opencard());
        dgpanel.add(dg15);
        dg16.addActionListener(new opencard());
        dgpanel.add(dg16);
        dg17.addActionListener(new opencard());
        dgpanel.add(dg17);
        dg18.addActionListener(new opencard());
        dgpanel.add(dg18);
        dg19.addActionListener(new opencard());
        dgpanel.add(dg19);
        dg20.addActionListener(new opencard());
        dgpanel.add(dg20);
        dg21.addActionListener(new opencard());
        dgpanel.add(dg21);
        dg22.addActionListener(new opencard());
        dgpanel.add(dg22);
        dg23.addActionListener(new opencard());
        dgpanel.add(dg23);
        dg24.addActionListener(new opencard());
        dgpanel.add(dg24);
        dg25.addActionListener(new opencard());
        dgpanel3.add(dg25);
        dg26.addActionListener(new opencard());
        dgpanel3.add(dg26);
        dg27.addActionListener(new opencard());
        dgpanel3.add(dg27);
        dg28.addActionListener(new opencard());
        dgpanel3.add(dg28);
        dg29.addActionListener(new opencard());
        dgpanel3.add(dg29);
        dg30.addActionListener(new opencard());
        dgpanel3.add(dg30);
        dg31.addActionListener(new opencard());
        dgpanel3.add(dg31);
        dg32.addActionListener(new opencard());
        dgpanel3.add(dg32);
        dg33.addActionListener(new opencard());
        dgpanel3.add(dg33);
        dg34.addActionListener(new opencard());
        dgpanel3.add(dg34);
        dg35.addActionListener(new opencard());
        dgpanel3.add(dg35);
        dg36.addActionListener(new opencard());
        dgpanel3.add(dg36);
        dg37.addActionListener(new opencard());
        dgpanel3.add(dg37);
        dg38.addActionListener(new opencard());
        dgpanel3.add(dg38);
        dg39.addActionListener(new opencard());
        dgpanel3.add(dg39);
        dg40.addActionListener(new opencard());
        dgpanel3.add(dg40);
        dg41.addActionListener(new opencard());
        dgpanel3.add(dg41);
        dg42.addActionListener(new opencard());
        dgpanel3.add(dg42);
        dg43.addActionListener(new opencard());
        dgpanel3.add(dg43);
        dg44.addActionListener(new opencard());
        dgpanel3.add(dg44);
        dg45.addActionListener(new opencard());
        dgpanel3.add(dg45);
        dg46.addActionListener(new opencard());
        dgpanel3.add(dg46);
        dg47.addActionListener(new opencard());
        dgpanel3.add(dg47);
        dg48.addActionListener(new opencard());
        dgpanel3.add(dg48);

        dgpanel.setLayout(null);

        dgpanel.setLayout((LayoutManager) GridLayout);
        dgpanel3.setLayout((LayoutManager)GridLayout);
        dgpanel2.setLayout(null);
        dgpanel3.setBounds(630,50,550,700);
        dgpanel.setBounds(10, 50, 550, 700);
        dgpanel2.add(dgpanel3);
        dgpanel2.add(dgpanel);
        dgframe.add(dgpanel2);

        dgpanel.setVisible(true);
        dgpanel2.setVisible(true);
        dgframe.setVisible(true);




    }

    /**
     * Κλάση ActionListener η οποία δέχεται το πάτημα κουμπιού του παίκτη
     */
    class opencard implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent event) {

            if(flag==false) {
                OpenCard((JButton) event.getSource());
            }



        }

    }

    /**
     * Μέθοδος η οποία ανοίγει την κάρτα/κουμπί
     * @param Rb1  που επιλέχθηκε από τον παίκτη
     */
    public void OpenCard(final JButton Rb1) {

        TimerTask task = new TimerTask() {
            @Override
            public void run() {
                CloseCard(Rb1,Rb2);
                dglabel.setText(Start_Frame.messages.getString("nowplaying"));
            }
        };
        Card_Game objcg = new Card_Game();
        Rb1.setIcon(GetIcon(Rb1));

        objgh.CountMoves(r);
        count++;
        imgname=GetImgn(Rb1);
        bpos= (int) HashButton.get(Rb1);
        objcp.GetPaction(bpos,imgname);
        if (count % 2 != 0) {
            imgname2= imgname;
            Rb2=Rb1;
            bpos= (int) HashButton.get(Rb2);
            objcp.CardIsOpenDuel(bpos);       //deinei sth cpu thn karta pou einai twra anoixth apo to xrhsth
            dglabel2.setText(Player_Names.Pnames[r]);
            ChangeRound();
            dglabel.setText(Start_Frame.messages.getString("nowplaying"));
        }
        else{
            count=0;
            if(objcg.CompareIcons(imgname,imgname2)) {

                if ((Object)Rb1!=(Object)Rb2){
                    dglabel.setText(Start_Frame.messages.getString("success"));
                    objgh.CountVictories(r);

                    if(objgh.VicSum()==24) {
                        int vmoves=objgh.WhoWon();
                        int r= objgh.WhoR();
                        int moves = objgh.GetMoves(r);
                        if(objgh.isDraw()){
                            dglabel.setText(Start_Frame.messages.getString("draw"));
                        }
                        else {
                            dglabel.setText(Player_Names.Pnames[r] +" "+ Start_Frame.messages.getString("victory1") +" "+ moves +  Start_Frame.messages.getString("victory2") +" "+ vmoves +  Start_Frame.messages.getString("victory3"));
                            dglabel2.setText(Start_Frame.messages.getString("gameover"));
                            objgh.setWinnerName(Player_Names.Pnames[r]);
                            objgh.ManageLeaderBoard();
                        }
                    }
                    MatchTrue(Rb1, Rb2);

                }
                else{
                    dglabel.setText(Start_Frame.messages.getString("samecard"));
                    pause.schedule(task,1000);
                }

            }
            else{
                pause.schedule(task,1000);
                dglabel.setText(Start_Frame.messages.getString("dontmatch"));

            }
        }

    }

    /**
     * Μέθοδος που δέχεται τα κουμπιά/καρτες
     * @param Rb1
     * @param Rb2
     * που δεν "ταίριαξαν" και εισάγει σε αυτά την "κλειστή" εικονα
     */
    public void CloseCard(JButton Rb1,JButton Rb2){
        Rb1.setIcon(closeIcon);
        Rb2.setIcon(closeIcon);
    }

    /**
     * Μέθοδος που δέχεται τα κουμπιά/κάρτες
     * @param Rb1
     * @param Rb2
     * που "μαζεύτηκαν" και τα απενεργοποιεί
     */
    public void MatchTrue(JButton Rb1,JButton Rb2){
        Rb1.setEnabled(false);
        objcp.CardCollected((Integer) HashButton.get(Rb1));
        Rb2.setEnabled(false);
        objcp.CardCollected((Integer) HashButton.get(Rb2));
    }

    /**
     * Μέθοδος που δέχεται το κουμπί/κάρτα
     * @param Rb1
     * και επιστρέφει
     * @return την εικόνα που του αντιστοιχεί
     */
    public ImageIcon GetIcon(JButton Rb1){
        int pos = (int) HashButton.get(Rb1);
       if(r==0) {
            imgname = Duel_Table.TDTable1[pos-1];
       }
       else{

               imgname = Duel_Table.TDTable2[pos - 25];

       }
        URL imageURL = getClass().getResource(imgname);
        icon = new ImageIcon(imageURL);
        return icon;
    }

    /**
     * Μέθοδος που δέχεται το κουμπί/κάρτα
     * @param Rb1
     * και επιστρέφει
     * @return το όνομα της εικόνας που του αντιστοιχεί
     */
    public String GetImgn(JButton Rb1){
        int pos = (int) HashButton.get(Rb1);
        if(r==0) {
            imgname = Duel_Table.TDTable1[pos - 1];
        }
        else{
             imgname =Duel_Table.TDTable2[pos-25];

        }
        return  imgname;

    }

    /**
     * Μέθοδος που αλλάζει το γύρο παιχνιδιού
     */
    public void ChangeRound(){
        r++;
        if(r>1){
            r=0;

        }
        dglabel2.setText(Player_Names.Pnames[r]);
        if(CheckCPUPlayer()) {
            CPUturn();
        }
    }

    /**
     * Μέθοδος η οποία "παίζει" τη σειρά του υπολογιστή
     */
    public void CPUturn() {
        TimerTask task1 = new TimerTask() {
            @Override
            public void run() {
                bpos=objcp.CPUPlayingDuel(CheckCPUDifficutly());
                OpenCard((JButton) getKey(HashButton,bpos));
            }
        };

        TimerTask task2 = new TimerTask() {
            @Override
            public void run() {
                bpos=objcp.CPUPlayingDuel(CheckCPUDifficutly());
                OpenCard((JButton) getKey(HashButton,bpos));
            }
        };
        pause.schedule(task1,2000);
        pause.schedule(task2,4000);
    }

    /**
     * Μέθοδος η οποία ελέγχει εάν είναι σειρά του υπολογιστή να παίξει και επιστρέφει
     * @return την αντίστοιχη λογική τιμή
     */
    public boolean CheckCPUPlayer(){
        flag = false;
        if(Player_Names.Pnames[r]==null){
            return flag;
        }
        if     (Player_Names.Pnames[r].equals("CPUGOLDFISH1") ||
                Player_Names.Pnames[r].equals("CPUKANGAROO1") ||
                Player_Names.Pnames[r].equals("CPUELEPHANT1")){
            flag = true;

        }

        return flag;
    }

    /**
     * Μέθοδος η οποία ελέγχει το επίπεδο δυσκολίας του υπολογιστή και επιστρέφει
     * @return την αντίστοιχη τιμή
     */
    public String CheckCPUDifficutly(){
        if     (Player_Names.Pnames[r].equals("CPUGOLDFISH1")){
            return "easy";
        }
        else if(Player_Names.Pnames[r].equals("CPUKANGAROO1")){
            return "medium";
        }
        else{
            return "difficult";
        }
    }


    /**
     * Μέθοδος η οποία δέχεται ορίσματα ακεραίων από τον υπολογιστή/παίκτη
     * @param map
     * @param value
     * @param <K>
     * @param <V>
     * και επιστρέφει
     * @return τα αντίστοιχα κουμπιά
     */
    public static <K, V> K getKey(Map<K, V> map, V value) {
        for (Map.Entry<K, V> entry : map.entrySet()) {
            if (value.equals(entry.getValue())) {
                return entry.getKey();
            }
        }
        return null;
    }

}
