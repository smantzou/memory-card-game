import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Locale;
import java.util.ResourceBundle;

public class Start_Frame {
    static ResourceBundle messages;
    private JFrame SFrame;
    private JPanel SPanel;
    private JLabel SLabel1;
    private JLabel SLabel2;
    private JButton solo;
    private JButton multi;
    private JButton duel;

    /**
     * Αρχικοποίηση των απαραίτητων στοιχείων για την δημιουργία του πρώτου παραθύρου
     * και αναγνώριση της προεπιλεγμένης γλώσσας στο σύστημα του χρήστη
     */
    public Start_Frame() {


        Locale locale = new Locale("el", "GR");
        messages = ResourceBundle.getBundle("messages", locale);

        locale =new Locale("en","US");
        messages = ResourceBundle.getBundle("messages", locale);

        locale = Locale.getDefault();
        messages = ResourceBundle.getBundle("messages", locale);




        SFrame = new JFrame("Memory Card Game");
        SPanel = new JPanel();
        SLabel1 = new JLabel(messages.getString("Hello"));
        SLabel2 = new JLabel(messages.getString("selectgmode"));
        solo = new JButton();
        multi = new JButton();
        duel = new JButton();


    }


    /**
     * Μορφοποίηση πρώτου παραθύρου
     */
    public void FirstWindow() {

        SFrame.setResizable(false);

        SFrame.setSize(1000, 700);
        SFrame.setLocationRelativeTo(null);

        SFrame.add(SPanel);
        SPanel.setLayout(null);


        SPanel.setVisible(true);

        SFrame.setVisible(true);
        SFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);



    }

    /**
     * Μορφοποίηση των textfield στο παράθυρο
     */
    public void FTexts() {

        SLabel1.setFont(Font.decode("Verdana-Bold-15"));
        SLabel1.setBounds(330, 10, 400, 50);
        SPanel.add(SLabel1);
        SLabel1.setVisible(true);

        SLabel2.setFont(Font.decode("Verdana-Bold-15"));
        SLabel2.setBounds(330, 70, 400, 50);
        SPanel.add(SLabel2);
        SLabel2.setVisible(true);
    }

    /**
     * Μορφοποίηση των buttons στο παράθυρο
     */
    public void FButtons() {

        solo.setBounds(390, 200, 200, 100);
        solo.setVisible(true);
        solo.setText(messages.getString("solob"));
        solo.addActionListener(new selectgame());
        SPanel.add(solo);

        multi.setBounds(390, 320, 200, 100);
        multi.setText(messages.getString("multib"));
        multi.setVisible(true);
        multi.addActionListener(new selectgame());
        SPanel.add(multi);

        duel.setBounds(390, 440, 200, 100);
        duel.setText(messages.getString("duelb"));
        duel.setVisible(true);
        duel.addActionListener(new selectgame());
        SPanel.add(duel);


    }

    /**
     * Κλάση Actionlistener η οποία εμφανίζει το ανάλογο modal παράθυρο το οποίο αντιστοιχεί στο πάτημα του χρήστη
     */
    class selectgame implements  ActionListener{
        @Override

        public void actionPerformed(ActionEvent event){
            Insert_Name objin = new Insert_Name();

            if(event.getSource()==solo){
                objin.MakeModal1();


            }
            else if(event.getSource()==multi){
                objin.MakeModal2();
            }
            else{
                objin.MakeModal3();
            }
        }
    }





}
