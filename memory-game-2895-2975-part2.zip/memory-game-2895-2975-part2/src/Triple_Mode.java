public class Triple_Mode {

    private True_Table ttrue;


    public Triple_Mode() {

    }

    /**
     * Μέθοδος που δέχεται το μέγεθος του πίνακα και καλεί μεθόδους για την αντιστοίχιση των κουμπιών
     * με τις εικόνες.
     */
    public boolean Triple_Game(int i, int j) {

        ttrue = new True_Table(i, j);
        ttrue.CreatePTable();
        ttrue.ShuffleTrue();
        return true;
    }
}
