public class Double_Mode {



    private True_Table dtrue;


    public Double_Mode() {

    }

    /**
     * Μέθοδος που δέχεται το μέγεθος του πίνακα και καλεί μεθόδους για την αντιστοίχιση των κουμπιών
     * με τις εικόνες.
     */

    public boolean Double_Game(int i, int j) {

        dtrue = new True_Table(i, j);
        dtrue.CreatePTable();
        dtrue.ShuffleTrue();
        return true;
    }
}
