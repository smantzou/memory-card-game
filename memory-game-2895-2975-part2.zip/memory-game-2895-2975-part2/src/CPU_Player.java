import java.util.HashMap;
import java.util.Random;

public class CPU_Player  {
    private Random rand;
    private HashMap<Integer, String> CPUcards = new HashMap<Integer, String>();
    private int i,j,pos1,pos2=2000,pos3=3000,meg,countsame=0,posr1,posr2=2000,posr3=3000, posz =1000;
    private int bposduel,countmed=0,counttriple=0,countrand=0,countduel=0;
    private String imgname,cpudif="dif",icon1,icon2;
    private boolean flag=false;

    /**
     * Αρχικοποίηση τιμών/διαστάσεων
     * @param i
     * @param j
     * για το μέγεθος του πίνακα παιχνιδού του υπολογιστή
     */
        public CPU_Player(int i , int j){
        this.i=i;
        this.j=j;
        rand = new Random();
        meg=i*j;
        }

    /**
     * Μέθοδος που δέχεται τη θέση
     * @param bpos που αντιστιχεί στο κουμπί που πατήθηκε και το όνομα της αντίστοιχης εικόνας
     * @param imgname
     * και έπειτα επιστρέφει μια τιμή για το αν πέτυχε το στόχο της
     * @return true/false
     */
        public boolean GetPaction(int bpos , String imgname){
        CPUcards.put(bpos,imgname);
        if(CPUcards.get(bpos)!=null){
            return true;
        }else{
            return false;
        }
        }

    /**
     *  Μέθοδος που δέχεται τη θέση
     * @param bpos που αντιστιχεί στην κάρτα που μαζεύτηκε
     * και έπειτα επιστρέφει μια τιμή για το αν πέτυχε το στόχο της
     * @return true/false
     */
        public boolean CardCollected(int bpos){
        CPUcards.put(bpos,"collected");
        if(CPUcards.get(bpos).equals("collected")){
            return true;
        }else
            return false;
        }

    /**
     *  Μέθοδος που δέχεται τη θέση
     * @param bpos που αντιστιχεί στην κάρτα που είναι τώρα "ανοιχτή"
     *  και έπειτα επιστρέφει μια τιμή για το αν πέτυχε το στόχο της
     * @return true/false
     */
        public boolean CardIsOpenDuel(int bpos){
            bposduel=bpos;
            icon1=CPUcards.get(bposduel);
            if(icon1!=null){
                return true;
            }
            else{
                return false;
            }
        }

    /**
     * Μέθοδος για το βασικό και διπλό που δέχεται το επίπεδο δυσκολίας
     * @param cpudifficulty του υπολογιστή και επιστρέφει
     * @return τη θέση της κάρτας που πρόκειται να "ανοίξει"
     */
        public int CPUPlaying(String cpudifficulty) {

            cpudif = cpudifficulty;

            if (cpudif.equals("easy")) {
                return GoldfishPlaying();
            }     else if (cpudif.equals("medium")) {
                if(countmed<2){
                    countmed++;
                    return GoldfishPlaying();
                }else{
                    countmed++;
                    if(countmed==4){
                        countmed=0;
                    }
                    return ElephantPlaying();
                }

            }     else {
               return ElephantPlaying();
            }
        }


    /**
     * Μέθοδος για το τριπλό που δέχεται το επίπεδο δυσκολίας
     * @param cpudifficulty του υπολογιστή και επιστρέφει
     * @return τη θέση της κάρτας που πρόκειται να "ανοίξει"
     */
        public int CPUPlayingTriple(String cpudifficulty){
            cpudif = cpudifficulty;

            if (cpudif.equals("easy")) {
                return GoldfishPlayingTriple();
            } else if (cpudif.equals("medium")) {
                if(countmed<3){
                    countmed++;

                    return GoldfishPlayingTriple();
                }else{
                    countmed++;

                    if(countmed==6){
                        countmed=0;
                    }
                    return ElephantPlayingTriple();
                }

            } else {
                return ElephantPlayingTriple();
            }
        }

    /**
     * Μέθοδος για τη μονομαχία που δέχεται το επίπεδο δυσκολίας
     * @param cpudifficulty του υπολογιστή και επιστρέφει
     * @return τη θέση της κάρτας που πρόκειται να "ανοίξει"
     */
        public int CPUPlayingDuel(String cpudifficulty){
            cpudif = cpudifficulty;

            if (cpudif.equals("easy")) {
                return GoldfishPlayingDuel();
            } else if (cpudif.equals("medium")) {
                if(countmed<2){
                    countmed++;

                    return GoldfishPlayingDuel();
                }else{
                    countmed++;

                    if(countmed==4){
                        countmed=0;
                    }
                    return ElephantPlayingDuel();
                }

            } else {
                return ElephantPlayingDuel();
            }
        }

    /**
     * Μέθοδος για τη μονομαχία που επιστρέφει
     * @return την τυχαία θέση της κάρτας που πρόκειται να "ανοίξει" ο υπολογιστης/χρυσόψαρο
     */
        public int GoldfishPlayingDuel(){
            posr1=rand.nextInt(24)+1+24;
            imgname=CPUcards.get(posr1);
            if (imgname != null) {
                if (imgname.equals("collected")) {
                    flag = true;
                }
            }
            while ((posr1 == posr2) || flag == true) {
                posr1 = rand.nextInt(24)+1+24;
                imgname = CPUcards.get(posr1);
                if (imgname != null) {
                    if (imgname.equals("collected")) {
                        flag = true;
                    } else {
                        flag = false;
                    }
                }

            }
            posr2 = posr1;
            return posr1;
        }

    /**
     *  Μέθοδος για τη μονομαχία που επιστρέφει
     * @return τη θέση της κάρτας που πρόκειται να "ανοίξει" ο υπολογιστης/ελέφαντας
     */
        public int ElephantPlayingDuel(){
            if(countduel==1){
                countduel=0;
                for(int i=25;i<=48;i++){
                    if(CPUcards.get(i)==null){
                        return i;
                    }
                }
                posr1=rand.nextInt(24)+24+1;
                while(CPUcards.get(posr1).equals("collected")){
                    posr1=rand.nextInt(24)+24+1;
                }
                return posr1;
            }
           else{
               countduel++;
                for(int i=25;i<=48;i++){
                    if(CPUcards.get(i)!=null){
                        if(CPUcards.get(i).equals(icon1)){
                            return i;
                        }
                    }
                   else{
                        for(int j=25;j<=48;j++){
                            if(CPUcards.get(i)==null){
                                return i;
                            }else{
                                posr1=rand.nextInt(24)+24+1;
                                while(CPUcards.get(posr1).equals("collected")){
                                    posr1=rand.nextInt(24)+24+1;
                                }
                                return posr1; // mallon pote de xreiazetai na ftasei edw
                            }
                        }
                    }
                }
            }

            return GoldfishPlayingDuel();
        }


    /**
     * Μέθοδος για το βασικό και διπλό που επιστρέφει
     * @return την τυχαία θέση της κάρτας που πρόκειται να "ανοίξει" ο υπολογιστης/χρυσόψαρο
     */
        public int GoldfishPlaying(){
            posr1=rand.nextInt(i*j)+1;
            imgname=CPUcards.get(posr1);
            if (imgname != null) {
                if (imgname.equals("collected")) {
                    flag = true;
                }
            }
            while ((posr1 == posr2) || flag == true) {
                posr1 = rand.nextInt(i * j) + 1;
                imgname = CPUcards.get(posr1);
                if (imgname != null) {
                    if (imgname.equals("collected")) {
                        flag = true;
                    } else {
                        flag = false;
                    }
                }

            }
            posr2 = posr1;
            return posr1;
        }

    /**
     *  Μέθοδος για το τριπλό που επιστρέφει
     * @return την τυχαία θέση της κάρτας που πρόκειται να "ανοίξει" ο υπολογιστης/χρυσόψαρο
     */
        public int GoldfishPlayingTriple(){
            counttriple++;
        posr1=rand.nextInt(i*j)+1;
        imgname=CPUcards.get(posr1);
        if (imgname != null) {
            if (imgname.equals("collected")) {
                flag = true;
            }
        }
        while ((posr1 == posr2) || (posr2==posr3) || (posr1==posr3) || flag == true) {
            posr1 = rand.nextInt(i * j) + 1;
            imgname = CPUcards.get(posr1);
            if (imgname != null) {
                if (imgname.equals("collected")) {
                    flag = true;
                } else {
                    flag = false;
                }
            }

        }
        if(counttriple==1){
            posr2 = posr1;

        }else if(counttriple==2) {
            posr3 = posr1;

        }
        else{
                counttriple=0;
                posr2=2000;
                posr3=3000;

        }

        return posr1;
        }

    /**
     * Μέθοδος για το βασικό και διπλό που επιστρέφει
     * @return τη θέση της κάρτας που πρόκειται να "ανοίξει" ο υπολογιστης/ελέφαντας
     */
        public int ElephantPlaying(){
            if(countsame==1 && !(CPUcards.get(pos2).equals("collected"))){
                countsame=0;
                return pos2;
            }else {
                countsame=0;
                for (int i = 1; i <= meg; i++) {

                    if (CPUcards.get(i) != null && !(CPUcards.get(i).equals("collected"))) {
                        icon1 = CPUcards.get(i);
                        for (int j = i + 1; j <= meg; j++) {
                            if (CPUcards.get(j) != null && (!(CPUcards.get(j).equals("collected")))) {
                                icon2 = CPUcards.get(j);

                                if (icon1.equals(icon2)) {
                                    countsame++;
                                    pos1 = i;
                                    pos2 = j;
                                    if(pos1== posz){
                                        countsame=0;
                                        posz =1000;
                                        return pos2;
                                    }else{
                                        return pos1;
                                    }

                                }
                            }
                        }
                    }
                }
                for (int z = 1; z <= meg; z++){
                    if(CPUcards.get(z)==null){
                        posz =z;
                        return posz;
                    }
                }

                return GoldfishPlaying();
            }

        }

    /**
     *  Μέθοδος για το τριπλό που επιστρέφει
     * @return τη θέση της κάρτας που πρόκειται να "ανοίξει" ο υπολογιστης/ελέφαντας
     */
        public int ElephantPlayingTriple(){
            if(countsame==1 && !(CPUcards.get(pos2).equals("collected"))){
                countsame++;
                return pos2;
            }else if(countsame==2 && !(CPUcards.get(pos3).equals("collected"))){
                countsame=0;
                return pos3;
            }else{
                countsame=0;
                if(countrand<2){
                    for(int i=1;i<=meg;i++){
                        if (CPUcards.get(i) != null && !(CPUcards.get(i).equals("collected"))){
                            icon1 = CPUcards.get(i);
                            for (int j = i + 1; j <= meg; j++){
                                if (icon1.equals(CPUcards.get(j)) ) {
                                    for (int z = j + 1; z <= meg; z++){
                                        if (icon1.equals(CPUcards.get(z)) ){
                                            countsame++;
                                            pos1 = i;
                                            pos2 = j;
                                            pos3 = z;
                                            if(pos1== posz){
                                                countrand=0;
                                                countsame=2;
                                                posz =1000;
                                                return pos2;
                                            }else if(pos2== posz){
                                                countrand=0;
                                                countsame=0;
                                                posz =2000;
                                                return pos3;
                                            }else{
                                                countrand=0;
                                                return pos1;
                                            }
                                        }
                                    }
                                }
                            }
                        }

                    }
                }

                for (int z = 1; z <= meg; z++){
                    if(CPUcards.get(z)==null){
                        countrand++;
                        if(countrand==3){
                            countrand=0;
                        }
                        posz =z;
                        return posz;
                    }
                }
            }

            return GoldfishPlayingTriple();
        }
    }




