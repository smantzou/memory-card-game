import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;


public class Resource_Manager {
    private ObjectOutputStream oos;
    private String filename;
    private static HashMap <Integer,Save_Data>ObjHash;
    private static int counter=0;
    private PrintWriter writer;

    /**
     * Αρχικοίηση της μεταβλητής ονόματος φακέλου και της HashMap αντικειμένων(ObjHash).
     */
    public Resource_Manager(){
        filename = "LeaderBoard.txt";

        ObjHash = new HashMap<>();
    }

    /**
     * Μέθοδος που καλείται για την αποθήκευση των High score των παικτών απο την HashMap .
     * και επιστρέφει μια boolean τιμή ανάλογα με το αν πέτυχε τον στόχο της,
     * @return true/false
     */
    public boolean save() {
        try {
            oos = new ObjectOutputStream(Files.newOutputStream(Paths.get(filename)));
        } catch (IOException e) {
            e.printStackTrace();
        }
        for(int i=1;i<=ObjHash.size();i++){
            try {
                oos.writeObject(ObjHash.get(i));
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        try {
            oos.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        if(oos.equals(null)){
            return false;
        }
        return true;
    }

    /**
     * Μέθοδος που δέχεται
     * @param datum ένα τύπου Save_Data αντικείμενο
     * και το τοποθετεί στην επομένη της τελευταίας θέσης της HashMap
     *  και επιστρέφει μια boolean τιμή ανάλογα με το αν πέτυχε τον στόχο της,
     * @return true/false
     */
    public boolean AddObject(Save_Data datum){

        counter= ObjHash.size()+1;
        ObjHash.put(counter,datum);
        if(ObjHash.get(counter)==null){
            return false;
        }
        return true;
    }


    /**
     * Μέθοδος που καλείται για την φόρτωση των αντικειμένων στην HashMap και δέχεται
     * @param filename το όνομα του αρχείου.
     * Έπειτα και επιστρέφει μια boolean τιμή ανάλογα με το αν πέτυχε τον στόχο της,
     * @return true/false
     * @throws IOException
     */
    public boolean load(String filename) throws IOException {
        try(ObjectInputStream ois = new ObjectInputStream(Files.newInputStream(Paths.get(filename)))){
            boolean flag=true;
            while(flag){
                try{
                    counter++;

                    ObjHash.put(counter, (Save_Data) ois.readObject());
                }catch(EOFException e){
                    flag=false;
                }
            }
        } catch (Exception e) {


        }
        if(ObjHash.get(1)==null){
            return false;
        }
        return true;
    }

    /**
     * Μέθοδος που ελέγχει την ύπαρξη
     * @param name ενός ονόματος που δέχεται,
     * στην HashMap και επιστρέφει μια τιμή boolean ανάλογη με την ύπαρξη η μη του ονόματος
     * @return true/false
     */
    public  boolean CheckExistance(String name) {
        if (name != null) {
            for (int i = 1; i <= ObjHash.size(); i++) {

                if (ObjHash.size() == 0) {
                    return false;
                }
                if (name.equals(ObjHash.get(i).getName())) {
                    return true;
                }

            }
            return false;
        }
        return false;
    }

    /**
     * Μέθοδος που δέχεται
     * @param name το όνομα του παίκτη
     * @param Steps τα βήματα που έκανε
     * @param Winner το αν νίκησε η όχι
     * @param multiorduel το αν παίζει Μονό η όχι
     * @param table τον τύπο πίνακα των καρτών
     * Και αλλάζει τα στατιστικά του ανάλογα με την επίδοση του
     * Έπειτα και επιστρέφει μια boolean τιμή ανάλογα με το αν πέτυχε τον στόχο της
     * @return true/false
     */
    public boolean ChangeStats(String name, int Steps, boolean Winner, boolean multiorduel, String table){
        for(int i=1;i<=ObjHash.size();i++){
            Save_Data datum = ObjHash.get(i);
            if(name.equals(datum.getName())){


                    if(!multiorduel){
                        if(table.equals("Basic")){
                            datum.Update_BSteps(Steps);
                        }
                        if(table.equals("Double")){
                            datum.Update_DSteps(Steps);
                        }
                        if(table.equals("Triple")){
                            datum.Update_TSteps(Steps);
                        }

                    }
                    else{
                        if(Winner){
                            if(table.equals("Basic")){
                                datum.Basic_Win();
                            }
                            if(table.equals("Double")){
                                datum.Double_Win();
                            }
                            if(table.equals("Triple")){
                                datum.Triple_Win();
                            }
                            if (table.equals("Duel")){
                                datum.Duel_Win();
                            }
                        }


                    }
                    return true;


                }

            ObjHash.put(i,datum);

        }
        return false;

    }

    /**
     * Μέθοδος που χρησιμοποιεί την κλάση PrintWriter για να συγγράψει ένα κείμενο με τις επιδόσεις των παικτών
     * και έπειτα και επιστρέφει μια boolean τιμή ανάλογα με το αν πέτυχε τον στόχο της
     * @return true/false
     */
    public boolean Write(){
        try {
            writer = new PrintWriter(Files.newOutputStream(Paths.get("Archive.txt")));
        } catch (IOException e) {
            e.printStackTrace();
        }
        for (int i=1;i<=ObjHash.size();i++){
            Save_Data datum = ObjHash.get(i);
            String bsteps = String.valueOf(datum.GetBasicSteps());
            String dsteps = String.valueOf(datum.GetDoubleSteps());
            String tsteps = String.valueOf(datum.GetTripleSteps());
            String bwins = String.valueOf(datum.GetBasicWins());
            String dwins = String.valueOf(datum.GetDoubleWins());
            String twins = String.valueOf(datum.GetTripleWins());
            String duelwins = String.valueOf(datum.GetDuelWins());
            writer.println("Player:"+datum.getName()+" has a best score of least steps of "+ bsteps +","+  dsteps+","+"and "+tsteps+" in Basic,Double and Triple Mode accordingly " );
            writer.println("and has "+bwins+","+dwins+","+twins+","+duelwins+" wins in in Basic,Double, Triple and Duel Mode accordingly. ");
        }
        writer.close();
        if(writer.equals(null)){
            return false;
        }
        return true;
    }



}
