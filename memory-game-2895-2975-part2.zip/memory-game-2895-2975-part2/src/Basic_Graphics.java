import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.net.URL;
import java.util.*;
import java.util.Timer;

public class Basic_Graphics extends Basic_Mode {

    private Resource_Manager objrm= new Resource_Manager();
    private Object GridLayout = new GridLayout(4, 6, 5, 3);
    private HashMap HashButton ;
    private JFrame bgframe;
    private JPanel bgpanel;
    private JPanel bgpanel2;
    private JLabel bglabel,bglabel2;
    private JButton bg1;
    private JButton bg2;
    private JButton bg3;
    private JButton bg4;
    private JButton bg5;
    private JButton bg6;
    private JButton bg7;
    private JButton bg8;
    private JButton bg9;
    private JButton bg10;
    private JButton bg11;
    private JButton bg12;
    private JButton bg13;
    private JButton bg14;
    private JButton bg15;
    private JButton bg16;
    private JButton bg17;
    private JButton bg18;
    private JButton bg19;
    private JButton bg20;
    private JButton bg21;
    private JButton bg22;
    private JButton bg23;
    private JButton bg24;
    private JButton Rb2;
    private ImageIcon closeIcon, icon;
    private int count = 0,countsame=0;
    private int r =0, numplayers =0,bpos;
    private String imgname, imgname2, imgName;
    private CPU_Player objcp = new CPU_Player(4,6);
    private boolean flag=false,banner=false;
    private Timer pause = new Timer();


    private Game_Handler objgh;

    /**
     * Άρχικοποίηση των στοιχείων για τη δημιουργία του παραθύρου παιχνιδιού στο βασικό
     */
    public Basic_Graphics() {
        objgh = new Game_Handler();
        if(Player_Names.Pnames[1]==null){
            objgh.setMultiduel(false);
        }
        else{
            objgh.setMultiduel(true);
        }
        objgh.setTable("Basic");
        bgframe = new JFrame("Memory Card Game!");
        bgpanel = new JPanel();
        bgpanel2 = new JPanel();
        bglabel = new JLabel();
        bglabel2 = new JLabel();
        bg1 = new JButton();
        bg2 = new JButton();
        bg3 = new JButton();
        bg4 = new JButton();
        bg5 = new JButton();
        bg6 = new JButton();
        bg7 = new JButton();
        bg8 = new JButton();
        bg9 = new JButton();
        bg10 = new JButton();
        bg11 = new JButton();
        bg12 = new JButton();
        bg13 = new JButton();
        bg14 = new JButton();
        bg15 = new JButton();
        bg16 = new JButton();
        bg17 = new JButton();
        bg18 = new JButton();
        bg19 = new JButton();
        bg20 = new JButton();
        bg21 = new JButton();
        bg22 = new JButton();
        bg23 = new JButton();
        bg24 = new JButton();
        HashButton = new HashMap<JButton,Integer>();
        HashStart();
        SetDefaultIcon();
        try {
            objrm.load("LeaderBoard.txt");
        } catch (IOException e) {
            e.printStackTrace();
        }


        super.Basic_Game(4, 6);



    }

    /**
     * Μέθοδος για τη δημιουργία του πίνακα που αντιστοιχίζει τα κουμπιά με ακέραιους αριθμούς/θέσεις
     *  και επιστρέφει τιμή για το αν πέτυχε το σκοπό της
     * @return true/false
     */
    public boolean HashStart(){
        HashButton.put(bg1,1);
        HashButton.put(bg2,2);
        HashButton.put(bg3,3);
        HashButton.put(bg4,4);
        HashButton.put(bg5,5);
        HashButton.put(bg6,6);
        HashButton.put(bg7,7);
        HashButton.put(bg8,8);
        HashButton.put(bg9,9);
        HashButton.put(bg10,10);
        HashButton.put(bg11,11);
        HashButton.put(bg12,12);
        HashButton.put(bg13,13);
        HashButton.put(bg14,14);
        HashButton.put(bg15,15);
        HashButton.put(bg16,16);
        HashButton.put(bg17,17);
        HashButton.put(bg18,18);
        HashButton.put(bg19,19);
        HashButton.put(bg20,20);
        HashButton.put(bg21,21);
        HashButton.put(bg22,22);
        HashButton.put(bg23,23);
        HashButton.put(bg24,24);
        for(Object x : HashButton.keySet()){
            if(HashButton.get(x)==null){
                return false;
            }
        }
        return true;
    }


    /**
     * Μέθοδος για την εισαγωγή της "κλειστής" εικόνας σε όλα τα κουμπιά/κάρτες στην αρχή του παιχνιδιού
     */
    public void SetDefaultIcon() {

        imgName = "ergasia eikones/cardclose.jpg";
        URL imageURL = getClass().getResource(imgName);
        closeIcon = new ImageIcon(imageURL);
        bg1.setIcon(closeIcon);
        bg2.setIcon(closeIcon);
        bg3.setIcon(closeIcon);
        bg4.setIcon(closeIcon);
        bg5.setIcon(closeIcon);
        bg6.setIcon(closeIcon);
        bg7.setIcon(closeIcon);
        bg8.setIcon(closeIcon);
        bg9.setIcon(closeIcon);
        bg10.setIcon(closeIcon);
        bg11.setIcon(closeIcon);
        bg12.setIcon(closeIcon);
        bg13.setIcon(closeIcon);
        bg14.setIcon(closeIcon);
        bg15.setIcon(closeIcon);
        bg16.setIcon(closeIcon);
        bg17.setIcon(closeIcon);
        bg18.setIcon(closeIcon);
        bg19.setIcon(closeIcon);
        bg20.setIcon(closeIcon);
        bg21.setIcon(closeIcon);
        bg22.setIcon(closeIcon);
        bg23.setIcon(closeIcon);
        bg24.setIcon(closeIcon);
    }

    /**
     * Μέθοδος εύρεσης του αριθμού των παικτών
     */
    public void NPmake(){
        for(int i=0;i<4;i++){
            if(Player_Names.Pnames[i]==null){
                break;
            }
            numplayers++;
        }
    }


    /**
     * Μέθοδος για τη δημιουργία του παραθύρου για το βασικό παιχνίδι
     */
    public void MakeBTable() {
        NPmake();
        bgframe.add(bgpanel2);
        bgframe.setSize(1200,800);
        bgframe.setLocationRelativeTo(null);
        bgframe.setResizable(false);

        bglabel.setText(Start_Frame.messages.getString("opencard"));
        bglabel.setBounds(200, -20, 1000, 100);
        bgpanel2.add(bglabel);


        bglabel2.setText(Player_Names.Pnames[r]);
        bglabel2.setBounds(80, 20, 1000, 100);
        bgpanel2.add(bglabel2);

        bg1.addActionListener(new opencard());
        bgpanel.add(bg1);
        bg2.addActionListener(new opencard());
        bgpanel.add(bg2);
        bg3.addActionListener(new opencard());
        bgpanel.add(bg3);
        bg4.addActionListener(new opencard());
        bgpanel.add(bg4);
        bg5.addActionListener(new opencard());
        bgpanel.add(bg5);
        bg6.addActionListener(new opencard());
        bgpanel.add(bg6);
        bg7.addActionListener(new opencard());
        bgpanel.add(bg7);
        bg8.addActionListener(new opencard());
        bgpanel.add(bg8);
        bg9.addActionListener(new opencard());
        bgpanel.add(bg9);
        bg10.addActionListener(new opencard());
        bgpanel.add(bg10);
        bg11.addActionListener(new opencard());
        bgpanel.add(bg11);
        bg12.addActionListener(new opencard());
        bgpanel.add(bg12);
        bg13.addActionListener(new opencard());
        bgpanel.add(bg13);
        bg14.addActionListener(new opencard());
        bgpanel.add(bg14);
        bg15.addActionListener(new opencard());
        bgpanel.add(bg15);
        bg16.addActionListener(new opencard());
        bgpanel.add(bg16);
        bg17.addActionListener(new opencard());
        bgpanel.add(bg17);
        bg18.addActionListener(new opencard());
        bgpanel.add(bg18);
        bg19.addActionListener(new opencard());
        bgpanel.add(bg19);
        bg20.addActionListener(new opencard());
        bgpanel.add(bg20);
        bg21.addActionListener(new opencard());
        bgpanel.add(bg21);
        bg22.addActionListener(new opencard());
        bgpanel.add(bg22);
        bg23.addActionListener(new opencard());
        bgpanel.add(bg23);
        bg24.addActionListener(new opencard());
        bgpanel.add(bg24);
        bgpanel.setLayout(null);


        bgpanel.setLayout((LayoutManager) GridLayout);





        bgpanel2.setLayout(null);

        bgpanel.setBounds(200, 50, 800, 700);
        bgpanel2.add(bgpanel);

        bgpanel.setVisible(true);
        bgpanel2.setVisible(true);
        bgframe.setVisible(true);



    }


    /**
     * Κλάση ActionListener η οποία δέχεται το πάτημα κουμπιού του παίκτη
     */
    class opencard implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent event) {
            if(flag==false && banner==false) {
                OpenCard((JButton) event.getSource());
            }
        }
    }


    /**
     * Μέθοδος η οποία ανοίγει την κάρτα/κουμπί
     * @param Rb1 που επιλέχθηκε από τον παίκτη
     */
    public void OpenCard(final JButton Rb1) {


        TimerTask task = new TimerTask() {
            @Override
            public void run() {

                CloseCard(Rb1,Rb2);
                banner=false;

            }
        };

        Card_Game objcg = new Card_Game();
        Rb1.setIcon(GetIcon(Rb1));
        objgh.CountMoves(r);
        count++;
        imgname=GetImgn(Rb1);
        bpos= (int) HashButton.get(Rb1);
        objcp.GetPaction(bpos,imgname);
        if (count % 2 != 0) {
            imgname2= imgname;
            Rb2=Rb1;
            bglabel.setText(Start_Frame.messages.getString("openscard"));

        }
        else{

            count=0;
            if(flag==false){
                banner =true;
            }

            if(objcg.CompareIcons(imgname,imgname2)) {

                if ((Object)Rb1!=(Object)Rb2){
                    bglabel.setText(Start_Frame.messages.getString("success"));
                    banner=false;
                    objgh.CountVictories(r);

                    if(objgh.VicSum()==12) {
                        int vmoves= objgh.WhoWon();
                        int r= objgh.WhoR();
                        int moves = objgh.GetMoves(r);


                        if(objgh.isDraw()){
                            bglabel.setText(Start_Frame.messages.getString("draw"));
                        }
                        else {
                            bglabel.setText(Player_Names.Pnames[r] +" "+ Start_Frame.messages.getString("victory1") +" "+ moves +  Start_Frame.messages.getString("victory2") +" "+ vmoves +  Start_Frame.messages.getString("victory3"));
                            objgh.setWinnerName(Player_Names.Pnames[r]);
                            objgh.ManageLeaderBoard();

                        }

                    }
                    MatchTrue(Rb1, Rb2);

                    if(flag==true && objgh.VicSum()<12){
                        CPUturn();
                    }
                }
                else{
                    bglabel.setText(Start_Frame.messages.getString("samecard"));
                    countsame++;
                    pause.schedule(task,1000);
                    if(countsame==2){
                        bglabel.setText(Start_Frame.messages.getString("samecardtwice"));
                        countsame=0;
                        ChangeRound();
                    }

                }

            }
            else{
                pause.schedule(task,1000);
                bglabel.setText(Start_Frame.messages.getString("dontmatch"));
                countsame=0;
                ChangeRound();

            }



        }

    }


    /**
     * Μέθοδος που δέχεται τα κουμπιά/καρτες
     * @param Rb1
     * @param Rb2
     * που δεν "ταίριαξαν" και εισάγει σε αυτά την "κλειστή" εικονα
     */
    public void CloseCard(JButton Rb1,JButton Rb2){
        Rb1.setIcon(closeIcon);
        Rb2.setIcon(closeIcon);
    }

    /**
     * Μέθοδος που δέχεται τα κουμπιά/κάρτες
     * @param Rb1
     * @param Rb2
     * που "μαζεύτηκαν" και τα απενεργοποιεί
     */
    public void MatchTrue(JButton Rb1,JButton Rb2){
        Rb1.setEnabled(false);
        objcp.CardCollected((Integer) HashButton.get(Rb1));
        Rb2.setEnabled(false);
        objcp.CardCollected((Integer) HashButton.get(Rb2));
    }

    /**
     * Μέθοδος που δέχεται το κουμπί/κάρτα
     * @param Rb1
     * και επιστρέφει
     * @return την εικόνα που του αντιστοιχεί
     */
    public ImageIcon GetIcon(JButton Rb1){
        int pos = (int) HashButton.get(Rb1);
        String imgname = True_Table.TTable[pos-1];
        URL imageURL = getClass().getResource(imgname);
        icon = new ImageIcon(imageURL);
        return icon;
    }

    /**
     * Μέθοδος που δέχεται το κουμπί/κάρτα
     * @param Rb1
     * και επιστρέφει
     * @return το όνομα της εικόνας που του αντιστοιχεί
     */
    public String GetImgn(JButton Rb1){
        int pos = (int) HashButton.get(Rb1);
        String imgname = True_Table.TTable[pos-1];
        return  imgname;

    }


    /**
     * Μέθοδος που αλλάζει το γύρο παιχνιδιού
     */
    public void ChangeRound(){
        r++;

        if(r>numplayers-1){
            r=0;

        }
        bglabel2.setText(Player_Names.Pnames[r]);
        if(CheckCPUPlayer()) {
            CPUturn();
        }

    }

    /**
     * Μέθοδος η οποία "παίζει" τη σειρά του υπολογιστή
     */
    public void CPUturn() {
        TimerTask task1 = new TimerTask() {
            @Override
            public void run() {
                bpos=objcp.CPUPlaying(CheckCPUDifficutly());
                OpenCard((JButton) getKey(HashButton,bpos));
            }
        };

        TimerTask task2 = new TimerTask() {
            @Override
            public void run() {
                bpos=objcp.CPUPlaying(CheckCPUDifficutly());
                OpenCard((JButton) getKey(HashButton,bpos));
            }
        };
        pause.schedule(task1,2000);
        pause.schedule(task2,3000);
    };


    /**
     * Μέθοδος η οποία ελέγχει εάν είναι σειρά του υπολογιστή να παίξει και επιστρέφει
     * @return την αντίστοιχη λογική τιμή
     */
    public boolean CheckCPUPlayer(){

        flag = false;
        if(Player_Names.Pnames[r]==null){
            return flag;
        }

        if     (Player_Names.Pnames[r].equals("CPUGOLDFISH1")|| Player_Names.Pnames[r].equals("CPUGOLDFISH2") || Player_Names.Pnames[r].equals("CPUGOLDFISH3") ||
                    Player_Names.Pnames[r].equals("CPUKANGAROO1") || Player_Names.Pnames[r].equals("CPUKANGAROO2") || Player_Names.Pnames[r].equals("CPUKANGAROO3") ||
                    Player_Names.Pnames[r].equals("CPUELEPHANT1") || Player_Names.Pnames[r].equals("CPUELEPHANT2") || Player_Names.Pnames[r].equals("CPUELEPHANT3")){
                flag = true;

            }


        return flag;

    }

    /**
     * Μέθοδος η οποία ελέγχει το επίπεδο δυσκολίας του υπολογιστή και επιστρέφει
     * @return την αντίστοιχη τιμή
     */
    public String CheckCPUDifficutly(){

        if     (Player_Names.Pnames[r].equals("CPUGOLDFISH1")|| Player_Names.Pnames[r].equals("CPUGOLDFISH2") || Player_Names.Pnames[r].equals("CPUGOLDFISH3")){
            return "easy";
        }
        else if(Player_Names.Pnames[r].equals("CPUKANGAROO1") || Player_Names.Pnames[r].equals("CPUKANGAROO2") || Player_Names.Pnames[r].equals("CPUKANGAROO3")){
            return "medium";
        }
        else{
            return "difficult";
        }
    }
    /**
     * Μέθοδος η οποία δέχεται ορίσματα ακεραίων από τον υπολογιστή/παίκτη
     * @param map
     * @param value
     * @param <K>
     * @param <V>
     * και επιστρέφει
     * @return τα αντίστοιχα κουμπιά
     */
    public static <K, V> K getKey(Map<K, V> map, V value) {
        for (Map.Entry<K, V> entry : map.entrySet()) {
            if (value.equals(entry.getValue())) {
                return entry.getKey();
            }
        }
        return null;
    }

}