
import java.util.HashMap;
public class Card_Game {
    static HashMap<Integer, String> Cards = new HashMap<Integer, String>();



    public Card_Game() {

    }

    /**
     * Μέθοδος που δέχεται δύο ονόματα εικόνων
     * @param imgname (το όνομα της πρώτης)
     * @param imgname2 (το όνομα της δεύτερης)
     * τις συγκρίνει και επιστρέψει την ανάλογη τιμή με το αν είναι ίδιες η όχι.
     * @return true/false
     */
    public boolean CompareIcons(String imgname, String imgname2) {
        if (imgname.equals(imgname2))
            return true;
        else
            return false;
    }



    /**
     * Αρχικοποιεί το HashMap που περιέχει όλα τα κλειδιά για κάθε μία απο τις 24 εικόνες
     */
    public boolean HashStart() {
        Cards.put(1,"ergasia eikones/avengers.png");
        Cards.put(2,"ergasia eikones/batman.png" );
        Cards.put(3,"ergasia eikones/captainamerica.jpg");
        Cards.put(4,"ergasia eikones/daizenchu.jpg" );
        Cards.put(5,"ergasia eikones/darthvader.png");
        Cards.put(6,"ergasia eikones/deathnote.jpg" );
        Cards.put(7,"ergasia eikones/fairytail.jpg" );
        Cards.put(8,"ergasia eikones/flash.png" );
        Cards.put(9,"ergasia eikones/godfather.png" );
        Cards.put(10,"ergasia eikones/greenlantern.jpg");
        Cards.put(11,"ergasia eikones/harrypotter.jpg" );
        Cards.put(12,"ergasia eikones/hxh.jpg" );
        Cards.put(13,"ergasia eikones/ironman.png" );
        Cards.put(14,"ergasia eikones/jacksparrow.png" );
        Cards.put(15,"ergasia eikones/lordoftherings.jpg" );
        Cards.put(16,"ergasia eikones/onepiece.png" );
        Cards.put(17,"ergasia eikones/pokeball.png" );
        Cards.put(18,"ergasia eikones/sherlock.jpg" );
        Cards.put(19,"ergasia eikones/spiderman.png" );
        Cards.put(20,"ergasia eikones/Superman.png" );
        Cards.put(21,"ergasia eikones/vforvendetta.png");
        Cards.put(22,"ergasia eikones/vikings.png" );
        Cards.put(23,"ergasia eikones/wonderwoman.png");
        Cards.put(24,"ergasia eikones/yugioh.jpg");
        for(int i =1;i<=24;i++){
            if(Cards.get(i)==null){
                return false;
            }
        }
        return  true;
    }
}

