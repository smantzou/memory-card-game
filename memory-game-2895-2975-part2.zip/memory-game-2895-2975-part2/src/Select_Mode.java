import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Select_Mode {

    private JDialog smdialog;
    private JPanel smpanel;
    private JLabel smlabel;
    private JButton smbasic;
    private JButton smdouble;
    private JButton smtriple;

    /**
     * Αρχίκοποίηση Dialog παραθύρου για την επιλογή είδους παιχνιδιού
     */
    public Select_Mode(){

        smdialog = new JDialog();
        smpanel = new JPanel();
        smlabel = new JLabel(Start_Frame.messages.getString("selectgmode"));
        smbasic = new JButton(Start_Frame.messages.getString("basic"));
        smdouble = new JButton(Start_Frame.messages.getString("double"));
        smtriple = new JButton(Start_Frame.messages.getString("triple"));
    }

    /**
     * Μέθοδος που μορφοποιεί το Dialog παράθυρο .
     */
    public void SMode() {
        smdialog.setSize(800,500);
        smdialog.setLocationRelativeTo(null);
        smdialog.add(smpanel);
        smdialog.setResizable(false);
        smdialog.setModal(true);

        smpanel.setLayout(null);

        smlabel.setBounds(300, 20, 300, 100);
        smpanel.add(smlabel);

        smbasic.setBounds(300, 100, 200, 100);
        smbasic.addActionListener(new letsplay());
        smpanel.add(smbasic);

        smdouble.setBounds(300, 210, 200, 100);
        smdouble.addActionListener(new letsplay());
        smpanel.add(smdouble);

        smtriple.setBounds(300, 320, 200, 100);
        smtriple.addActionListener(new letsplay());
        smpanel.add(smtriple);

        smpanel.setVisible(true);
        smdialog.setVisible(true);
    }

    /**
     * Κλάση ActionListener που καλεί το αντίστοιχο είδος παιχνιδιού με την επιλογή του χρήστη.
     */
    class letsplay implements ActionListener{


        @Override
        public  void actionPerformed (ActionEvent event){

            smdialog.setModal(false);
            smdialog.dispose();
            if(event.getSource()==smbasic){
                Basic_Graphics objbg = new Basic_Graphics();
                objbg.MakeBTable();
            }
            else if(event.getSource()==smdouble){
                Double_Graphics objdg = new Double_Graphics();
                objdg.MakeDTable();

            }
            else{
                Triple_Graphics objtg = new Triple_Graphics();
                objtg.MakeTTable();

            }
        }
    }
}
