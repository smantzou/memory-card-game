public class Main {


    /**
     *
     * @param args
     */
    public static void main(String[] args) {

      Card_Game mem = new Card_Game();        //Δημιουργία αντικειμένου mem
      mem.HashStart();                        //Δημιουργία και αρχικοποίηση HashMap
      Start_Frame fra = new Start_Frame();    //Δημιουργία αντικειμένου fra
        fra.FirstWindow();                    //Κλήση συναρτήσεων για την δημιουργία πρώτου frame
        fra.FTexts();
        fra.FButtons();
      Player_Names ob = new Player_Names();   //Κλήση constructor για την δημιουργία του πίνακα ονομάτων
    }
}










