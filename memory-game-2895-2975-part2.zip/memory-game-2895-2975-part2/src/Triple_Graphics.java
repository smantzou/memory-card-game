import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;

public class Triple_Graphics extends Triple_Mode {

    private final Game_Handler objgh;
    private Resource_Manager objrm = new Resource_Manager();
    private Object GridLayout = new GridLayout(6, 8, 5, 3);
    private HashMap HashButton;
    private JFrame tgframe;
    private JPanel tgpanel;
    private JPanel tgpanel2;
    private JLabel tglabel;
    private JButton tg1;
    private JButton tg2;
    private JButton tg3;
    private JButton tg4;
    private JButton tg5;
    private JButton tg6;
    private JButton tg7;
    private JButton tg8;
    private JButton tg9;
    private JButton tg10;
    private JButton tg11;
    private JButton tg12;
    private JButton tg13;
    private JButton tg14;
    private JButton tg15;
    private JButton tg16;
    private JButton tg17;
    private JButton tg18;
    private JButton tg19;
    private JButton tg20;
    private JButton tg21;
    private JButton tg22;
    private JButton tg23;
    private JButton tg24;
    private JButton tg25;
    private JButton tg26;
    private JButton tg27;
    private JButton tg28;
    private JButton tg29;
    private JButton tg30;
    private JButton tg31;
    private JButton tg32;
    private JButton tg33;
    private JButton tg34;
    private JButton tg35;
    private JButton tg36;
    private JButton Rb2, Rb3;
    private ImageIcon closeIcon, icon;
    private int count = 0 ,r = 0, numplayers = 0,bpos,countsame=0;
    private String imgname, imgname2, imgname3, imgName;
    private JLabel tglabel2;
    private CPU_Player objcp = new CPU_Player(6,6);
    private boolean flag=false,banner=false;
    private Timer pause = new Timer();


    /**
     * Άρχικοποίηση των στοιχείων για τη δημιουργία του παραθύρου παιχνιδιού στο τριπλό
     */
    public Triple_Graphics() {
        objgh = new Game_Handler();
        if(Player_Names.Pnames[1]==null){
            objgh.setMultiduel(false);
        }
        else{
            objgh.setMultiduel(true);
        }
        objgh.setTable("Triple");
        super.Triple_Game(6, 6);
        tgframe = new JFrame("Memory Card Game!");
        tgpanel = new JPanel();
        tgpanel2 = new JPanel();
        tglabel = new JLabel();
        tg1 = new JButton();
        tg2 = new JButton();
        tg3 = new JButton();
        tg4 = new JButton();
        tg5 = new JButton();
        tg6 = new JButton();
        tg7 = new JButton();
        tg8 = new JButton();
        tg9 = new JButton();
        tg10 = new JButton();
        tg11 = new JButton();
        tg12 = new JButton();
        tg13 = new JButton();
        tg14 = new JButton();
        tg15 = new JButton();
        tg16 = new JButton();
        tg17 = new JButton();
        tg18 = new JButton();
        tg19 = new JButton();
        tg20 = new JButton();
        tg21 = new JButton();
        tg22 = new JButton();
        tg23 = new JButton();
        tg24 = new JButton();
        tg25 = new JButton();
        tg26 = new JButton();
        tg27 = new JButton();
        tg28 = new JButton();
        tg29 = new JButton();
        tg30 = new JButton();
        tg31 = new JButton();
        tg32 = new JButton();
        tg33 = new JButton();
        tg34 = new JButton();
        tg35 = new JButton();
        tg36 = new JButton();
        tglabel2 = new JLabel();

        HashButton = new HashMap<JButton, Integer>();


        SetDefaultIcon();
        try {
            objrm.load("LeaderBoard.txt");
        } catch (IOException e) {
            e.printStackTrace();
        }




    }

    /**
     * Μέθοδος για τη δημιουργία του πίνακα που αντιστοιχίζει τα κουμπιά με ακέραιους αριθμούς/θέσεις
     *  και επιστρέφει τιμή για το αν πέτυχε το σκοπό της
     * @return true/false
     */
    public boolean HashStart() {
        HashButton.put(tg1, 1);
        HashButton.put(tg2, 2);
        HashButton.put(tg3, 3);
        HashButton.put(tg4, 4);
        HashButton.put(tg5, 5);
        HashButton.put(tg6, 6);
        HashButton.put(tg7, 7);
        HashButton.put(tg8, 8);
        HashButton.put(tg9, 9);
        HashButton.put(tg10, 10);
        HashButton.put(tg11, 11);
        HashButton.put(tg12, 12);
        HashButton.put(tg13, 13);
        HashButton.put(tg14, 14);
        HashButton.put(tg15, 15);
        HashButton.put(tg16, 16);
        HashButton.put(tg17, 17);
        HashButton.put(tg18, 18);
        HashButton.put(tg19, 19);
        HashButton.put(tg20, 20);
        HashButton.put(tg21, 21);
        HashButton.put(tg22, 22);
        HashButton.put(tg23, 23);
        HashButton.put(tg24, 24);
        HashButton.put(tg25, 25);
        HashButton.put(tg26, 26);
        HashButton.put(tg27, 27);
        HashButton.put(tg28, 28);
        HashButton.put(tg29, 29);
        HashButton.put(tg30, 30);
        HashButton.put(tg31, 31);
        HashButton.put(tg32, 32);
        HashButton.put(tg33, 33);
        HashButton.put(tg34, 34);
        HashButton.put(tg35, 35);
        HashButton.put(tg36, 36);
        for(Object x : HashButton.keySet()){
            if(HashButton.get(x)==null){
                return false;
            }
        }
        return true;

    }

    /**
     * Μέθοδος για την εισαγωγή της "κλειστής" εικόνας σε όλα τα κουμπιά/κάρτες στην αρχή του παιχνιδιού
     */
    public void SetDefaultIcon() {

        imgName = "ergasia eikones/cardclose.jpg";
        URL imageURL = getClass().getResource(imgName);

        closeIcon = new ImageIcon(imageURL);
        tg1.setIcon(closeIcon);
        tg2.setIcon(closeIcon);
        tg3.setIcon(closeIcon);
        tg4.setIcon(closeIcon);
        tg5.setIcon(closeIcon);
        tg6.setIcon(closeIcon);
        tg7.setIcon(closeIcon);
        tg8.setIcon(closeIcon);
        tg9.setIcon(closeIcon);
        tg10.setIcon(closeIcon);
        tg11.setIcon(closeIcon);
        tg12.setIcon(closeIcon);
        tg13.setIcon(closeIcon);
        tg14.setIcon(closeIcon);
        tg15.setIcon(closeIcon);
        tg16.setIcon(closeIcon);
        tg17.setIcon(closeIcon);
        tg18.setIcon(closeIcon);
        tg19.setIcon(closeIcon);
        tg20.setIcon(closeIcon);
        tg21.setIcon(closeIcon);
        tg22.setIcon(closeIcon);
        tg23.setIcon(closeIcon);
        tg24.setIcon(closeIcon);
        tg25.setIcon(closeIcon);
        tg26.setIcon(closeIcon);
        tg27.setIcon(closeIcon);
        tg28.setIcon(closeIcon);
        tg29.setIcon(closeIcon);
        tg30.setIcon(closeIcon);
        tg31.setIcon(closeIcon);
        tg32.setIcon(closeIcon);
        tg33.setIcon(closeIcon);
        tg34.setIcon(closeIcon);
        tg35.setIcon(closeIcon);
        tg36.setIcon(closeIcon);

    }

    /**
     * Μέθοδος εύρεσης του αριθμού των παικτών
     */
    public void NPmake() {
        for (int i = 0; i < 4; i++) {
            if (Player_Names.Pnames[i] == null) {
                break;
            }
            numplayers++;
        }
    }

    /**
     * Μέθοδος για τη δημιουργία του παραθύρου για το τριπλό παιχνίδι
     */
    public void MakeTTable() {
        NPmake();
        HashStart();
        tgframe.add(tgpanel2);
        tgframe.setSize(1200,800);
        tgframe.setLocationRelativeTo(null);
        tgframe.setResizable(false);

        tglabel2.setText(Player_Names.Pnames[0]);
        tglabel2.setBounds(80, 20, 1000, 100);
        tgpanel2.add(tglabel2);

        tglabel.setText(Start_Frame.messages.getString("opencard"));
        tglabel.setBounds(200, -20, 1000, 100);
        tgpanel2.add(tglabel);

        tg1.addActionListener(new opencard());
        tgpanel.add(tg1);
        tg2.addActionListener(new opencard());
        tgpanel.add(tg2);
        tg3.addActionListener(new opencard());
        tgpanel.add(tg3);
        tg4.addActionListener(new opencard());
        tgpanel.add(tg4);
        tg5.addActionListener(new opencard());
        tgpanel.add(tg5);
        tg6.addActionListener(new opencard());
        tgpanel.add(tg6);
        tg7.addActionListener(new opencard());
        tgpanel.add(tg7);
        tg8.addActionListener(new opencard());
        tgpanel.add(tg8);
        tg9.addActionListener(new opencard());
        tgpanel.add(tg9);
        tg10.addActionListener(new opencard());
        tgpanel.add(tg10);
        tg11.addActionListener(new opencard());
        tgpanel.add(tg11);
        tg12.addActionListener(new opencard());
        tgpanel.add(tg12);
        tg13.addActionListener(new opencard());
        tgpanel.add(tg13);
        tg14.addActionListener(new opencard());
        tgpanel.add(tg14);
        tg15.addActionListener(new opencard());
        tgpanel.add(tg15);
        tg16.addActionListener(new opencard());
        tgpanel.add(tg16);
        tg17.addActionListener(new opencard());
        tgpanel.add(tg17);
        tg18.addActionListener(new opencard());
        tgpanel.add(tg18);
        tg19.addActionListener(new opencard());
        tgpanel.add(tg19);
        tg20.addActionListener(new opencard());
        tgpanel.add(tg20);
        tg21.addActionListener(new opencard());
        tgpanel.add(tg21);
        tg22.addActionListener(new opencard());
        tgpanel.add(tg22);
        tg23.addActionListener(new opencard());
        tgpanel.add(tg23);
        tg24.addActionListener(new opencard());
        tgpanel.add(tg24);
        tg25.addActionListener(new opencard());
        tgpanel.add(tg25);
        tg26.addActionListener(new opencard());
        tgpanel.add(tg26);
        tg27.addActionListener(new opencard());
        tgpanel.add(tg27);
        tg28.addActionListener(new opencard());
        tgpanel.add(tg28);
        tg29.addActionListener(new opencard());
        tgpanel.add(tg29);
        tg30.addActionListener(new opencard());
        tgpanel.add(tg30);
        tg31.addActionListener(new opencard());
        tgpanel.add(tg31);
        tg32.addActionListener(new opencard());
        tgpanel.add(tg32);
        tg33.addActionListener(new opencard());
        tgpanel.add(tg33);
        tg34.addActionListener(new opencard());
        tgpanel.add(tg34);
        tg35.addActionListener(new opencard());
        tgpanel.add(tg35);
        tg36.addActionListener(new opencard());
        tgpanel.add(tg36);


        tgpanel.setLayout(null);

        tgpanel.setLayout((LayoutManager) GridLayout);

        tgpanel2.setLayout(null);

        tgpanel.setBounds(200, 50, 800, 700);
        tgpanel2.add(tgpanel);

        tgpanel.setVisible(true);
        tgpanel2.setVisible(true);
        tgframe.setVisible(true);



    }

    /**
     *  Κλάση ActionListener η οποία δέχεται το πάτημα κουμπιού του παίκτη
     */
    class opencard implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent event) {
            if(flag==false && banner==false) {
                OpenCard((JButton) event.getSource());
            }

        }


    }

    /**
     *  Μέθοδος η οποία ανοίγει την κάρτα/κουμπί
     * @param Rb1 που επιλέχθηκε από τον παίκτη
     */
    public void OpenCard(final JButton Rb1) {

        TimerTask task = new TimerTask() {
            @Override
            public void run() {

                CloseCard(Rb1, Rb2, Rb3);
                banner=false;
            }
        };
        Card_Game objcg = new Card_Game();
        Rb1.setIcon(GetIcon(Rb1));
        objgh.CountMoves(r);
        count++;
        imgname = GetImgn(Rb1);
        bpos = (int) HashButton.get(Rb1);
        objcp.GetPaction(bpos, imgname);
        if (count == 1) {
            imgname2 = imgname;
            Rb2 = Rb1;
            tglabel.setText(Start_Frame.messages.getString("openscard"));

        } else if (count == 2) {
            imgname3 = imgname;
            Rb3 = Rb1;
            tglabel.setText(Start_Frame.messages.getString("opentcard"));
        } else {
            count = 0;
            if(flag==false){
                banner = true;
            }
            if (objcg.CompareIcons(imgname, imgname2) && objcg.CompareIcons(imgname3, imgname)) {

                if ((Object) Rb1 != (Object) Rb2 && (Object) Rb1 != (Object) Rb3 && (Object) Rb2 != (Object) Rb3) {
                    MatchTrue(Rb1, Rb2, Rb3);
                    banner=false;
                    if (flag == true && objgh.VicSum() < 12) {
                        CPUturn();
                    }
                    tglabel.setText(Start_Frame.messages.getString("success"));

                    objgh.CountVictories(r);
                    if (objgh.VicSum() == 12) {
                        int vmoves = objgh.WhoWon();
                        int r = objgh.WhoR();
                        int moves = objgh.GetMoves(r);
                        if (objgh.isDraw()) {
                            tglabel.setText(Start_Frame.messages.getString("draw"));
                        } else {
                            tglabel.setText(Player_Names.Pnames[r] +" "+ Start_Frame.messages.getString("victory1") +" "+ moves +  Start_Frame.messages.getString("victory2") +" "+ vmoves +  Start_Frame.messages.getString("victory3fortriple"));
                            objgh.setWinnerName(Player_Names.Pnames[r]);
                            objgh.ManageLeaderBoard();
                        }

                    }


                } else {
                    tglabel.setText(Start_Frame.messages.getString("samecard"));
                    countsame++;
                    pause.schedule(task,1000);
                    if(countsame==2){
                        tglabel.setText(Start_Frame.messages.getString("samecardtwice"));
                        countsame=0;
                        ChangeRound();
                    }

                }

            } else {
                pause.schedule(task, 1000);
                tglabel.setText(Start_Frame.messages.getString("dontmatch"));
                countsame=0;
                ChangeRound();
            }
        }
    }

    /**
     * Μέθοδος που δέχεται τα κουμπιά/καρτες
     * @param Rb1
     * @param Rb2
     * @param Rb3
     * που δεν "ταίριαξαν" και εισάγει σε αυτά την "κλειστή" εικονα
     */
      public void CloseCard (JButton Rb1, JButton Rb2, JButton Rb3) {
        Rb1.setIcon(closeIcon);
        Rb2.setIcon(closeIcon);
        Rb3.setIcon(closeIcon);
    }

    /**
     * Μέθοδος που δέχεται τα κουμπιά/κάρτες
     * @param Rb1
     * @param Rb2
     * @param Rb3
     * που "μαζεύτηκαν" και τα απενεργοποιεί
     */
    public void MatchTrue (JButton Rb1, JButton Rb2, JButton Rb3){
        Rb1.setEnabled(false);
        objcp.CardCollected((Integer) HashButton.get(Rb1));
        Rb2.setEnabled(false);
        objcp.CardCollected((Integer) HashButton.get(Rb2));
        Rb3.setEnabled(false);
        objcp.CardCollected((Integer) HashButton.get(Rb3));
    }

    /**
     * Μέθοδος που δέχεται το κουμπί/κάρτα
     * @param Rb1
     * και επιστρέφει
     * @return την εικόνα που του αντιστοιχεί
     */
    public ImageIcon GetIcon (JButton Rb1){
        int pos = (int) HashButton.get(Rb1);
        String imgname = True_Table.TTable[pos - 1];
        URL imageURL = getClass().getResource(imgname);
        icon = new ImageIcon(imageURL);
        return icon;
    }

    /**
     * Μέθοδος που δέχεται το κουμπί/κάρτα
     * @param Rb1
     * και επιστρέφει
     * @return
     * το όνομα της εικόνας που του αντιστοιχεί
     */
    public String GetImgn (JButton Rb1){
        int pos = (int) HashButton.get(Rb1);
        String imgname = True_Table.TTable[pos - 1];
        return imgname;
    }

    /**
     *  Μέθοδος που αλλάζει το γύρο παιχνιδιού
     */
    public void ChangeRound(){
        r++;
        if(r>numplayers-1){
            r=0;

        }
        tglabel2.setText(Player_Names.Pnames[r]);
        if(CheckCPUPlayer()) {
            CPUturn();
        }
    }

    /**
     * Μέθοδος η οποία "παίζει" τη σειρά του υπολογιστή
     */
    public void CPUturn() {
        TimerTask task1 = new TimerTask() {
            @Override
            public void run() {
                bpos=objcp.CPUPlayingTriple(CheckCPUDifficutly());
                OpenCard((JButton) getKey(HashButton,bpos));
            }
        };

        TimerTask task2 = new TimerTask() {
            @Override
            public void run() {
                bpos=objcp.CPUPlayingTriple(CheckCPUDifficutly());
                OpenCard((JButton) getKey(HashButton,bpos));
            }
        };
        TimerTask task3 = new TimerTask() {
            @Override
            public void run() {
                bpos=objcp.CPUPlayingTriple(CheckCPUDifficutly());
                OpenCard((JButton) getKey(HashButton,bpos));
            }
        };
        pause.schedule(task1,2000);
        pause.schedule(task2,3000);
        pause.schedule(task3,4000);
    }

    /**
     * Μέθοδος η οποία ελέγχει εάν είναι σειρά του υπολογιστή να παίξει και επιστρέφει
     * @return την αντίστοιχη λογική τιμή
     */
    public boolean CheckCPUPlayer(){
        flag = false;
        if(Player_Names.Pnames[r]==null){
            return flag;
        }

        if     (Player_Names.Pnames[r].equals("CPUGOLDFISH1")|| Player_Names.Pnames[r].equals("CPUGOLDFISH2") || Player_Names.Pnames[r].equals("CPUGOLDFISH3") ||
                Player_Names.Pnames[r].equals("CPUKANGAROO1") || Player_Names.Pnames[r].equals("CPUKANGAROO2") || Player_Names.Pnames[r].equals("CPUKANGAROO3") ||
                Player_Names.Pnames[r].equals("CPUELEPHANT1") || Player_Names.Pnames[r].equals("CPUELEPHANT2") || Player_Names.Pnames[r].equals("CPUELEPHANT3")){
            flag = true;

        }


        return flag;
    }

    /**
     * Μέθοδος η οποία ελέγχει το επίπεδο δυσκολίας του υπολογιστή και επιστρέφει
     * @return την αντίστοιχη τιμή
     */
    public String CheckCPUDifficutly(){
        if     (Player_Names.Pnames[r].equals("CPUGOLDFISH1")|| Player_Names.Pnames[r].equals("CPUGOLDFISH2") || Player_Names.Pnames[r].equals("CPUGOLDFISH3")){
            return "easy";
        }
        else if(Player_Names.Pnames[r].equals("CPUKANGAROO1") || Player_Names.Pnames[r].equals("CPUKANGAROO2") || Player_Names.Pnames[r].equals("CPUKANGAROO3")){
            return "medium";
        }
        else{
            return "difficult";
        }
    }


    /**
     * Μέθοδος η οποία δέχεται ορίσματα ακεραίων από τον υπολογιστή/παίκτη
     * @param map
     * @param value
     * @param <K>
     * @param <V>
     * και επιστρέφει
     * @return τα αντίστοιχα κουμπιά
     */
    public static <K, V> K getKey(Map<K, V> map, V value) {
        for (Map.Entry<K, V> entry : map.entrySet()) {
            if (value.equals(entry.getValue())) {
                return entry.getKey();
            }
        }
        return null;
    }
}