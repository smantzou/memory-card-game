import java.util.Random;

public class Duel_Table {
    private Random shuffle = new Random();
    private boolean flag;
    private int gr;
    private int i;
    private int j;
    private static String PTable[];
    protected static String TDTable1[];
    protected static String TDTable2[];
    private int meg;

    /**
     * Αρχικοποίηση τιμών/διαστάσεων για το μέγεθος του πίνακα παιχνιδού μονομαχία
     */
    public Duel_Table() {
        i = 4;
        j = 6;
        meg = i * j;
        TDTable1 = new String[meg];
        TDTable2 =new String[meg];
        PTable = new String[meg];

    }

    /**
     * Μέθοδος που εισάγει στοιχεία από την HashMap στον  πρωτότυπο μονοδιάστατο (βοηθητικό) πίνακα για αποθήκευση όλων των εικόνων
     * και επιστρέφει τιμή για το αν πέτυχε το σκοπό της
     * @return true/false
     */
    public boolean CreatePTable() {


            for (int l = 0; l < meg; l++) {
                PTable[l] = Card_Game.Cards.get(l+1);
            }
            for(int i=0;i<24;i++){
                if(PTable[i]!=null){
                    return false;
                }
            }
            return true;

    }

    /**
     * Μέθοδος που δημιουργεί ένα μονοδιάστατο πίνακα για τον πρώτο παίκτη της μονομαχίας με τυχαία τοποθέτηση των εικόνων από το μονοδιάστατο βοηθητικό,
     * χρησιμοποιώντας ένα Random αντικείμενο και επιστρέφει τιμή για το αν πέτυχε το σκοπό της
     * @return true/false
     */
    public boolean ShuffleDTrue1() {

        for (int l = 0; l < meg; l++) {
            flag = false;
            while (!flag ) {
                gr = shuffle.nextInt(meg);
                if (TDTable1[gr] == null) {
                    TDTable1[gr]= PTable[l];
                    flag = true;
                }

            }

        }
        for(int i=0;i<24;i++){
            if(PTable[i]!=null){
                return false;
            }
        }
        return true;

    }

    /**
     * Μέθοδος που δημιουργεί ένα μονοδιάστατο πίνακα για το δεύτερο παίκτη της μονομαχίας με τυχαία τοποθέτηση των εικόνων από το μονοδιάστατο βοηθητικό,
     * χρησιμοποιώντας ένα Random αντικείμενο και επιστρέφει τιμή για το αν πέτυχε το σκοπό της
     * @return true/false
     */
    public boolean ShuffleDTrue2() {

        for (int l = 0; l < meg; l++) {
            flag = false;
            while (!flag ) {
                gr = shuffle.nextInt(meg);
                if (TDTable2[gr] == null) {
                    TDTable2[gr]= PTable[l];

                    flag = true;
                }

            }

        }
        for(int i=0;i<24;i++){
            if(PTable[i]!=null){
                return false;
            }
        }
        return true;

    }
}
