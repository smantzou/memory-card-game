import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Insert_Name {
    private JDialog NDialog;
    private JDialog CPUDialog;
    private JPanel CPUPanel;
    private JPanel NPanel;
    private JLabel NLabel;
    private JLabel NLabel2;
    private JLabel CPULabel;
    private JTextField NText1;
    private JTextField NText2;
    private JButton p2;
    private JButton p3;
    private JButton p4;
    private JButton OK;
    private JButton cpu1, dif1, dif2, dif3;
    private String player1;
    private Select_Mode objsm;

    /**
     * Αρχικοποίηση των απαραίτητων στοιχείων για την δημιουργία του παραθύρου ειγαγωγής ονομάτων
     * (Κουμπιών,πάνελ,ετικετών,και textfield)
     */
    public Insert_Name() {

        NDialog = new JDialog();
        CPUDialog = new JDialog();
        NPanel = new JPanel();
        CPUPanel = new JPanel();
        NLabel = new JLabel();
        NLabel2 = new JLabel();
        CPULabel = new JLabel(Start_Frame.messages.getString("difcpu"));
        NText1 = new JTextField();
        NText2 = new JTextField();
        p2 = new JButton(Start_Frame.messages.getString("p2"));
        p3 = new JButton(Start_Frame.messages.getString("p3"));
        p4 = new JButton(Start_Frame.messages.getString("p4"));
        OK = new JButton("OK");
        cpu1 = new JButton(Start_Frame.messages.getString("actcpu1"));
        dif1 = new JButton(Start_Frame.messages.getString("goldfish"));
        dif2 = new JButton(Start_Frame.messages.getString("kangaroo"));
        dif3 = new JButton(Start_Frame.messages.getString("elephant"));
        objsm = new Select_Mode();

    }

    /**
     * Συνάρτηση η οποία δημιουργεί το modal παράθυρο για την εισαγωγή του ονόματος παίκτη στο ΜΟΝΟ.
     */
    public void MakeModal1() {

        NDialog.add(NPanel);
        NDialog.setSize(800,500);
        NDialog.setLocationRelativeTo(null);
        NDialog.setModal(true);
        NDialog.setResizable(false);

        NPanel.add(NLabel);
        NPanel.add(NText1);
        NPanel.setLayout(null);

        OK.setBounds(601, 190, 60, 60);
        NPanel.add(OK);
        OK.addActionListener(new entername());

        NLabel.setBounds(130, 170, 300, 100);
        NLabel.setText(Start_Frame.messages.getString("entername"));
        NText1.setBounds(401, 195, 200, 50);
        NText1.addActionListener(new entername());

        NDialog.setVisible(true);
        NPanel.setVisible(true);


    }

    /**
     * Κλάση Actionlistener η οποία αποθηκεύει το όνομα του παίκτη και κλείνει το modal παράθυρο.
     */
    class entername implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent event) {

            if (event.getSource() == OK) {

                player1 = NText1.getText();
                Player_Names.Pnames[0] = player1;

                NDialog.setModal(false);
                NDialog.dispose();
                objsm.SMode();

            }
        }
    }

    /**
     * Συνάρτηση η οποία δημιουργεί το modal παράθυρο για την εισαγωγή των ονομάτων των παικτών στο παιχνίδι πολλαπλών παικτών.
     */
    public void MakeModal2() {
        NDialog.add(NPanel);
        NDialog.setSize(800,500);
        NDialog.setLocationRelativeTo(null);
        NDialog.setModal(true);
        NDialog.setResizable(false);

        p2.setBounds(300, 70, 200, 100);
        p2.addActionListener(new selectplayers());

        p3.setBounds(300, 180, 200, 100);
        p3.addActionListener(new selectplayers());

        p4.setBounds(300, 290, 200, 100);
        p4.addActionListener(new selectplayers());

        NPanel.add(p2);
        NPanel.add(p3);
        NPanel.add(p4);

        NLabel.setBounds(280, 0, 300, 100);
        NLabel.setText(Start_Frame.messages.getString("selectnplayers"));
        NPanel.add(NLabel);
        NPanel.setLayout(null);

        NDialog.setVisible(true);
        NPanel.setVisible(true);


    }

    /**
     * Κλάση Actionlistener η οποία καλεί την ανάλογη μέθοδο της κλάσης Multi_Modals αντίστοιχη με τον επιθυμητό αριθμό παικτών στο πολλαπλό παιχνίδι.
     */
    class selectplayers implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent event) {
            Multi_Modals objmm = new Multi_Modals();
            if (event.getSource() == p2) {
                objmm.P2Modal();
            } else if (event.getSource() == p3) {
                objmm.P3Modal();
            } else {
                objmm.P4Modal();
            }
            NDialog.setModal(false);
            NDialog.dispose();
        }
    }

    /**
     * Συνάρτηση η οποία δημιουργεί το modal παράθυρο για την εισαγωγή των ονομάτων των παικτών στη Μονομαχία.
     */
    public void MakeModal3() {
        NDialog.add(NPanel);
        NDialog.setSize(800,500);
        NDialog.setLocationRelativeTo(null);
        NDialog.setModal(true);
        NDialog.setResizable(false);

        NPanel.add(NLabel);
        NPanel.add(NLabel2);
        NPanel.add(NText1);
        NPanel.add(NText2);
        NPanel.setLayout(null);

        OK.setBounds(350, 300, 80, 80);
        OK.addActionListener(new enterduel());
        NPanel.add(OK);

        cpu1.setBounds(601, 230, 150, 40);
        cpu1.addActionListener(new activatecpu());
        NPanel.add(cpu1);

        NLabel.setBounds(130, 100, 300, 100);
        NLabel.setText(Start_Frame.messages.getString("entername1"));
        NText1.setBounds(401, 130, 200, 40);


        NLabel2.setBounds(130, 200, 300, 100);
        NLabel2.setText(Start_Frame.messages.getString("entername2"));
        NText2.setBounds(401, 230, 200, 40);

        NDialog.setVisible(true);
        NPanel.setVisible(true);
    }

    /**
     * Κλάση Actionlistener η οποία αποθηκεύει τα ονόματα των παικτών οι οποίοι θα παίξουν στην μονομαχία.
     */
    class enterduel implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent event) {
            if (event.getSource() == OK) {

                player1 = NText1.getText();
                String player2 = NText2.getText();
                Player_Names.Pnames[0] = player1;
                Player_Names.Pnames[1] = player2;
                Duel_Graphics objdg = new Duel_Graphics();

                NDialog.setModal(false);
                NDialog.dispose();
                objdg.MakeDTable();
            }
        }

    }

    /**
     * Κλάση Actionlistener η οποία εμφανίζει το modal παράθυρο στο οποίο ο χρήστης ενεργοποίει το παιχνίδι με τον υπολογιστή στην Μονομαχία.
     */
    class activatecpu implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent event) {
            makeCPUmodal();
        }


        /**
         * Δημιουργία παραθύρου για την επιλογή δυσκολίας της CPU για την Μονομαχία.
         */
        public void makeCPUmodal() {
            CPUDialog.setSize(800,500);
            CPUDialog.setLocationRelativeTo(null);
            CPUDialog.setModal(true);
            CPUDialog.setResizable(false);

            CPUPanel.setLayout(null);
            CPUDialog.add(CPUPanel);

            CPULabel.setBounds(300, -20, 300, 100);
            CPUPanel.add(CPULabel);

            dif1.setBounds(320, 80, 150, 80);
            dif1.addActionListener(new cpudifficulty());
            CPUPanel.add(dif1);

            dif2.setBounds(320, 180, 150, 80);
            dif2.addActionListener(new cpudifficulty());
            CPUPanel.add(dif2);

            dif3.setBounds(320, 280, 150, 80);
            dif3.addActionListener(new cpudifficulty());
            CPUPanel.add(dif3);

            CPUPanel.setVisible(true);
            CPUDialog.setVisible(true);


        }

        /**
         * Κλάση Actionlistener η οποία αποθηκεύει την προεπιλεγμένη δυσκολία της CPU για τη Μονομαχία.
         */
        class cpudifficulty implements ActionListener {
            @Override
            public void actionPerformed(ActionEvent event) {
                if (event.getSource() == dif1) {
                    NText2.setText("CPUGOLDFISH1");
                } else if (event.getSource() == dif2) {
                    NText2.setText("CPUKANGAROO1");
                } else {
                    NText2.setText("CPUELEPHANT1");
                }
                CPUDialog.setModal(false);
                CPUDialog.dispose();
            }

        }
    }
}
