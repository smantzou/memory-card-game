public class Basic_Mode {



   private True_Table btrue;


    public Basic_Mode(){


    }

    /**
     * Μέθοδος που δέχεται το μέγεθος του πίνακα και καλεί μεθόδους για την αντιστοίχιση των κουμπιών
     * με τις εικόνες.
     */
    public boolean Basic_Game(int i , int j){
        btrue = new True_Table(i,j);
        btrue.CreatePTable();
        btrue.ShuffleTrue();
        return true;
    }

}
