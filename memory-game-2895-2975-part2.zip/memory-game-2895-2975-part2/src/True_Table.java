import java.util.Random;


public class True_Table {
    private Random shuffle = new Random();
    private boolean flag;
    private int ep = 1;
    private int k = 1;
    private int gr;
    private int i;
    private int j;
    private static String PTable[];
    protected static String TTable[];
    private int meg;

    public True_Table(int i, int j) {   //Αρχικοποίηση στατικών πινάκων
        this.i = i;
        this.j = j;
        meg = i * j;
        TTable = new String[meg];
        PTable = new String[meg];
    }

    /**
     * Μέθοδος που εισάγει στοιχεία από την HashMap στον  πρωτότυπο μονοδιάστατο (βοηθητικό) πίνακα για αποθήκευση όλων των εικόνων.
     */
    public boolean CreatePTable() {

        if (i != j) {

            for (int l = 0; l < meg; l++) {

                PTable[l] = Card_Game.Cards.get(k);

                if (ep % 2 == 0)
                    k++;
                ep++;

            }


        } else {
            for (int l = 0; l < meg; l++) {

                PTable[l] = Card_Game.Cards.get(k);
                if (ep == 3) {
                    k++;
                    ep = 0;
                }
                ep++;


            }
        }
        for(int k=0;k<meg;k++){
            if(PTable[k]==null){
                return false;
            }
        }
        return true;

    }

    /**
     * Μέθοδος που δημιουργεί ένα μονοδιάστατο πίνακα με τυχαία τοποθέτηση των εικόνων από το μονοδιάστατο βοηθητικό
     * ,χρησιμοποιώντας ένα Random αντικείμενο.
     */
    public boolean ShuffleTrue() {

        for (int l = 0; l < meg; l++) {
            flag = false;
            while (!flag) {
                gr = shuffle.nextInt(meg);
                if (TTable[gr] == null) {
                    TTable[gr] = PTable[l];
                    flag = true;
                }

            }

        }
        for(int k=0;k<meg;k++){
            if(PTable[k]==null){
                return false;
            }
        }
        return true;

    }
}





