import org.junit.Test;

import static org.junit.Assert.*;

public class Duel_TableTest {
Duel_Table objdt = new Duel_Table();

    @Test
    public void createPTable() {
        assertTrue(objdt.CreatePTable());
    }

    @Test
    public void shuffleDTrue1() {
        assertTrue(objdt.ShuffleDTrue1());
    }

    @Test
    public void shuffleDTrue2() {
        assertTrue(objdt.ShuffleDTrue2());
    }
}