import org.junit.Test;

import static org.junit.Assert.*;

public class Double_GraphicsTest {
Double_Graphics objdg = new Double_Graphics();
    @Test
    public void hashStart() {
        assertTrue(objdg.HashStart());
    }



    @Test
    public void checkCPUPlayer() {
        Player_Names objpn = new Player_Names();
        assertNotEquals(objdg.CheckCPUPlayer(),null);
    }


}