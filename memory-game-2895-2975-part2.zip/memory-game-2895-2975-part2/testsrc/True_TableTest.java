import org.junit.Test;

import static org.junit.Assert.*;

public class True_TableTest {
    True_Table objtt= new True_Table(4,6);
    Card_Game objcd = new Card_Game();


    @Test
    public void createPTable() {
        objcd.HashStart();
      assertTrue(objtt.CreatePTable());
    }

    @Test
    public void shuffleTrue() {
        objcd.HashStart();
        objtt.CreatePTable();
        assertTrue(objtt.ShuffleTrue());
    }
}