import org.junit.Test;

import static org.junit.Assert.*;

public class Duel_GraphicsTest {
Duel_Graphics objdg = new Duel_Graphics();


    @Test
    public void hashStart() {
        assertTrue(objdg.HashStart());
    }







    @Test
    public void checkCPUPlayer() {
        Player_Names objpn = new Player_Names();
        assertNotEquals(objdg.CheckCPUPlayer(),null);
    }






}