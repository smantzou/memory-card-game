import org.junit.Test;

import static org.junit.Assert.*;

public class Game_HandlerTest {
Game_Handler objgh = new Game_Handler();

    @Test
    public void countMoves() {
        assertTrue(objgh.CountMoves(1));
    }

    @Test
    public void countVictories() {
        assertTrue(objgh.CountVictories(1));
    }
    @Test
    public void checkCPUPlayerForLeader() {
        Player_Names objpn = new Player_Names();
        assertNotEquals(objgh.CheckCPUPlayerForLeader(),null);
    }
    @Test
    public void vicSum() {

        assertNotEquals(objgh.VicSum(),null);
    }

    @Test
    public void whoWon() {
        assertNotEquals(objgh.WhoWon(),null);

    }

    @Test
    public void whoR() {
        assertNotEquals(objgh.WhoR(),null);

    }

    @Test
    public void getMoves() {
        assertNotEquals(objgh.GetMoves(1),null);
    }

    @Test
    public void isDraw() {
        assertNotEquals(objgh.isDraw(),null);

    }
}