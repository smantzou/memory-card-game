import org.junit.Test;

import static org.junit.Assert.*;

public class CPU_PlayerTest {
CPU_Player objcp = new CPU_Player(4,6);
    @Test
    public void getPaction() {
        assertTrue(objcp.GetPaction(1,"name"));
    }

    @Test
    public void cardCollected() {
        assertTrue(objcp.CardCollected(1));
    }

    @Test
    public void cardIsOpenDuel() {
        assertTrue(objcp.CardCollected(1));
    }

    @Test
    public void CPUPlaying() {
        assertNotEquals(objcp.CPUPlaying("easy"),null);
    }

    @Test
    public void CPUPlayingTriple() {
        assertNotEquals(objcp.CPUPlayingTriple("easy"),null);
    }

    @Test
    public void CPUPlayingDuel() {
        assertNotEquals(objcp.CPUPlayingDuel("easy"),null);
    }

    @Test
    public void goldfishPlayingDuel() {
        assertNotEquals(objcp.GoldfishPlayingDuel(),null);
    }

    @Test
    public void elephantPlayingDuel() {
        assertNotEquals(objcp.ElephantPlayingDuel(),null);
    }

    @Test
    public void goldfishPlaying() {
        assertNotEquals(objcp.GoldfishPlaying(),null);
    }

    @Test
    public void goldfishPlayingTriple() {
        assertNotEquals(objcp.GoldfishPlayingTriple(),null);
    }

    @Test
    public void elephantPlaying() {
        assertNotEquals(objcp.ElephantPlaying(),null);
    }

    @Test
    public void elephantPlayingTriple() {
        assertNotEquals(objcp.ElephantPlayingTriple(),null);
    }
}