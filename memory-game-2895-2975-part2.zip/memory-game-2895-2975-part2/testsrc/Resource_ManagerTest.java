import org.junit.Test;

import java.io.IOException;

import static org.junit.Assert.*;

public class Resource_ManagerTest {
    Resource_Manager objrm = new Resource_Manager();
    @Test
    public void save() {
        assertEquals(objrm.save(),true);
    }

    @Test
    public void addObject() {
        Save_Data datum = new Save_Data();
        datum.NewPlayer("smantzou");
        assertEquals(objrm.AddObject(datum),true);

    }

    @Test
    public void load() {
        Save_Data datum = new Save_Data();
        datum.NewPlayer("GeoAK");
        objrm.AddObject(datum);
        objrm.save();
        try {
            assertEquals(objrm.load("LeaderBoard.txt"),true);
        } catch (IOException e) {
            e.printStackTrace();
        }

    }


    @Test
    public void checkExistance() {
        Save_Data datum = new Save_Data();
        datum.NewPlayer("GeoAK");
        objrm.AddObject(datum);
        assertTrue(String.valueOf(objrm.CheckExistance("GeoAk")),true);
    }

    @Test
    public void changeStats() {
        Save_Data datum = new Save_Data();
        datum.NewPlayer("GeoAK");
        objrm.AddObject(datum);
        assertEquals(objrm.ChangeStats("GeoAK",50,false,false,"Basic"),true);
    }

    @Test
    public void write() {
        Save_Data datum = new Save_Data();
        datum.NewPlayer("GeoAK");
        objrm.AddObject(datum);
        assertEquals(objrm.Write(),true);
    }
}