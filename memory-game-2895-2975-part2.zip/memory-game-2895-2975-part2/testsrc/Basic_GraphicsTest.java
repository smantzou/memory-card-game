import org.junit.Test;

import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertTrue;

public class Basic_GraphicsTest {
Basic_Graphics objbg = new Basic_Graphics();
    @Test
    public void hashStart() {
        assertTrue(objbg.HashStart());
    }










    @Test
    public void checkCPUPlayer() {
        Player_Names objpn = new Player_Names();
        assertNotEquals(objbg.CheckCPUPlayer(),null);
    }





}