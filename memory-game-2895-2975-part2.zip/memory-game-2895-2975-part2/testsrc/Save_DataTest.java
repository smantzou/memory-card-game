import org.junit.Test;

import static org.junit.Assert.*;

public class Save_DataTest {
    Save_Data datum = new Save_Data();
    @Test
    public void newPlayer() {
        assertTrue(datum.NewPlayer("Lightbringer"));
    }

    @Test
    public void basic_Win() {
        datum.NewPlayer("Lightbringer");
        int x = datum.GetBasicWins();
        datum.Basic_Win();
        assertNotEquals(x, datum.GetBasicWins());
    }

    @Test
    public void double_Win() {
        datum.NewPlayer("Lightbringer");
        int x = datum.GetDoubleWins();
        datum.Double_Win();
        assertNotEquals(x, datum.GetDoubleWins());
    }

    @Test
    public void triple_Win() {
        datum.NewPlayer("Lightbringer");
        int x = datum.GetTripleWins();
        datum.Triple_Win();
        assertNotEquals(x, datum.GetTripleWins());
    }

    @Test
    public void duel_Win() {
        datum.NewPlayer("Lightbringer");
        int x = datum.GetDuelWins();
        datum.Duel_Win();
        assertNotEquals(x, datum.GetDuelWins());
    }

    @Test
    public void update_BSteps() {
        datum.NewPlayer("GeoAk");
        int x = datum.GetBasicSteps();
        datum.Update_BSteps(100);
        assertNotEquals(x,datum.GetBasicSteps());
    }

    @Test
    public void update_DSteps() {
        datum.NewPlayer("GeoAk");
        int x = datum.GetDoubleSteps();
        datum.Update_DSteps(100);
        assertNotEquals(x, datum.GetDoubleSteps());
    }

    @Test
    public void update_TSteps() {
        datum.NewPlayer("GeoAk");
        int x = datum.GetTripleSteps();
        datum.Update_TSteps(100);
        assertNotEquals(x, datum.GetTripleSteps());
    }

    @Test
    public void getBasicWins() {
        assertNotEquals(datum.GetBasicWins(),null);
    }

    @Test
    public void getDoubleWins() {
        assertNotEquals(datum.GetDoubleWins(),null);
    }

    @Test
    public void getTripleWins() {
        assertNotEquals(datum.GetTripleWins(),null);
    }

    @Test
    public void getDuelWins() {
        assertNotEquals(datum.GetDuelWins(),null);
    }

    @Test
    public void getBasicSteps() {
        assertNotEquals(datum.GetBasicSteps(),null);
    }

    @Test
    public void getDoubleSteps() {
        assertNotEquals(datum.GetDoubleSteps(),null);
    }

    @Test
    public void getTripleSteps() {
        assertNotEquals(datum.GetTripleSteps(),null);
    }

    @Test
    public void getName() {
        datum.NewPlayer("GeoAk98");
        assertEquals(datum.getName(),"GeoAk98");
    }
}