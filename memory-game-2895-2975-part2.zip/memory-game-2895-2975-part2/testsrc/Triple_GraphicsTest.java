import org.junit.Test;

import static org.junit.Assert.*;

public class Triple_GraphicsTest {
Triple_Graphics objtg = new Triple_Graphics();
    @Test
    public void hashStart() {
        assertTrue(objtg.HashStart());

    }







    @Test
    public void checkCPUPlayer() {
        Player_Names objpn = new Player_Names();
        assertNotEquals(objtg.CheckCPUPlayer(),null);
    }






}