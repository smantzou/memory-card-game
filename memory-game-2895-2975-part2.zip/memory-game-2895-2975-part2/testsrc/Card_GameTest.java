import org.junit.Test;

import static org.junit.Assert.*;

public class Card_GameTest {
    Card_Game objcd = new Card_Game();

    @Test
    public void compareIcons() {
        assertTrue(objcd.CompareIcons("Hello","Hello"));
    }

    @Test
    public void hashStart() {
       assertTrue(objcd.HashStart());
    }

}