import org.junit.Test;

import static org.junit.Assert.*;

public class Basic_ModeTest {
    Basic_Mode objbm = new Basic_Mode();
    @Test
    public void basic_Game() {
        assertTrue(objbm.Basic_Game(4,6));
    }
}