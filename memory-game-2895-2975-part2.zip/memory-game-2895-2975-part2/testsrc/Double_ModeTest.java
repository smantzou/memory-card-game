import org.junit.Test;

import static org.junit.Assert.*;

public class Double_ModeTest {
    Double_Mode objdb = new Double_Mode();
    @Test
    public void double_Game() {
        assertTrue(objdb.Double_Game(6,8));
    }
}