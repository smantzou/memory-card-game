import org.junit.Test;

import static org.junit.Assert.*;

public class Triple_ModeTest {
    Triple_Mode objtm = new Triple_Mode();
    @Test
    public void triple_Game() {
        assertTrue(objtm.Triple_Game(6,6));
    }
}